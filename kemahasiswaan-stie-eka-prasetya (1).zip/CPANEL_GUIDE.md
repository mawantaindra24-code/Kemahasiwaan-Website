# Panduan Lengkap Migrasi ke cPanel (Node.js & MySQL)

Ikuti panduan ini langkah demi langkah untuk memindahkan aplikasi Anda ke hosting cPanel.

## 1. Persiapan Database (MySQL)
Lakukan ini pertama kali di cPanel:
1.  **Cari menu "MySQL® Databases"** di dashboard cPanel Anda.
2.  **Buat Database Baru**: Beri nama (contoh: `user_kemahasiswaan`).
3.  **Buat User Database**: Masukkan username dan password yang kuat. **Catat password ini!**
4.  **Add User To Database**: Tambahkan user yang baru dibuat ke database tersebut. Centang **"ALL PRIVILEGES"**.
5.  **Impor Data**:
    - Buka menu **"phpMyAdmin"**.
    - Pilih database Anda di kolom kiri.
    - Klik tab **"Import"**.
    - Pilih file `database.sql` dari komputer Anda dan klik **"Go"**.

## 2. Mengunggah File ke Hosting
1.  **Compress File**: Zip semua file aplikasi Anda kecuali folder `node_modules` and `dist`.
2.  **Upload**: Gunakan **"File Manager"** cPanel, upload ke folder tujuan (misal: `public_html` atau folder sub-domain).
3.  **Extract**: Klik kanan file zip tersebut dan pilih **"Extract"**.

## 3. Konfigurasi Node.js di cPanel
1.  **Cari menu "Setup Node.js App"** di cPanel.
2.  **Create Application**:
    - **Node.js version**: Kami sangat menyarankan memilih **`18.20.8`** (atau `18.x` lainnya) karena versi ini paling stabil dan kompatibel dengan sebagian besar server hosting cPanel dibanding versi `22.x` yang sering mengalami error ketidakcocokan library OS (GLIBC).
    - **Application mode**: Pilih `Production`.
    - **Application root**: Isi sesuai folder tempat Anda menyimpan file (misal: `kemahasiswaan.eka-prasetya.ac.id`).
    - **Application URL**: Pilih domain/sub-domain Anda.
    - **Application startup file**: Isi dengan **`app.js`** (Kami telah membuatkan file `app.js` ini di root proyek Anda untuk menjamin proses booting aman tanpa langsung crash ketika mendeteksi file build belum ter-compile).
3.  Klik **"CREATE"** atau **"SAVE"**.

## 4. Konfigurasi Environment Variables (.env) dan JWT_SECRET
Kembali ke **File Manager**, buat file bernama `.env` di folder root aplikasi Anda, lalu isi atau sesuaikan dengan data berikut:
```env
DB_HOST=localhost
DB_USER=username_database_anda (lengkap dengan prefix cpanel, misal: u12345_admin)
DB_PASSWORD=password_yang_anda_buat_tadi
DB_NAME=nama_database_anda (lengkap dengan prefix, misal: u12345_db)
JWT_SECRET=RRA5Z3D9F8S7E6X1C2V3B4N5M6K7L8J9H0_KunciRahasiaAnda
PORT=3000
```
*Pastikan tidak ada spasi di sekitar tanda `=`.*

### Apa itu JWT_SECRET dan Bagaimana Cara Membuatnya?
`JWT_SECRET` adalah kunci rahasia acak yang digunakan aplikasi untuk mengenkripsi token keamanan login pengguna (agar token login tidak bisa dipalsukan).
**Cara membuatnya bebas dan sangat mudah:**
- Anda bisa mengetik sembarang kombinasi huruf, angka, dan karakter spesial yang panjang dan sulit ditebak.
- **Contoh aman**: `SupaDup4_SeCr3t_Key_Kemahasiswaan_2026_!@#`
- **Atau generate via Terminal/SSH** jika ada akses: jalankan perintah `openssl rand -base64 32` lalu copy hasilnya ke `.env`.

## 5. Instalasi dan Build
Kembali ke menu **"Setup Node.js App"**:
1.  Klik tombol **"Run NPM Install"**. Tunggu sampai selesai (jika sukses, tulisan status akan berubah).
2.  Jika sudah selesai, klik tombol **"Run JS script"**.
3.  Pilih **"build"** dan klik **"RUN JS SCRIPT"**.
    *Proses ini otomatis memanggil kompilator Vite dan Esbuild untuk melahirkan folder rilis `dist` di hosting Anda.*

## 6. Menjalankan Aplikasi
1.  Klik tombol **"START APP"** atau klik **"RESTART"**.
2.  Selamat! Aplikasi Anda sekarang sudah online dan bisa diakses via browser.

---

## ⚠️ Troubleshooting (Penting!)

### Mengatasi: "Unknown error occurred. Contact support for resolution." (Screenshot Anda)
Jika tombol **SAVE** gagal diklik dan mendatangkan pop-up error merah ini di cPanel:
1.  **Ubah Versi Node.js ke `18.20.8`**: Beberapa web-hosting belum memiliki library compiler yang mumpuni untuk menjalankan Node v22. Versi `18` adalah pilihan teraman dan paling direkomendasikan.
2.  **Gunakan `app.js` sebagai Startup File**: Jika Anda menulis `dist/server.cjs` sebelum proses build selesai dijalankan, cPanel akan mendeteksi file kosong/hilang dan langsung menolak penyimpanan dengan pesan "Unknown error". Menggunakan `app.js` yang selalu ada di root akan mengatasi masalah ini secara permanen.
3.  **Cek Izin Hak Akses file `.htaccess`**: 
    - Buka File Manager di cPanel.
    - Pastikan file `.htaccess` di folder aplikasi Anda memiliki izin (permission) **`644`**.
    - Jika izinnya `444` (read-only), cPanel tidak bisa menulis konfigurasi Node ke sana, sehingga memicu error misterius ini.

### Error: "Can't acquire lock for app" atau "Red [object Object]"
Jika muncul error ini seperti di screenshot Anda:
1.  Klik tombol **"STOP APP"** terlebih dahulu.
2.  Tunggu sekitar 30 detik.
3.  Ulangi langkah **"Run NPM Install"** atau **"START APP"**.
4.  Jika masih membandel, hapus folder `tmp` yang ada di root aplikasi melalui File Manager, lalu coba klik tombolnya kembali.
