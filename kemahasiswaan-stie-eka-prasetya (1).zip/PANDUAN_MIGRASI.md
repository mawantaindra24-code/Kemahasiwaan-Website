# Panduan Migrasi Proyek ke cPanel (STIE Eka Prasetya)

Dokumen ini berisi panduan langkah demi langkah untuk memindahkan aplikasi **Kemahasiswaan STIE Eka Prasetya** dari lingkungan AI Studio ke hosting cPanel Anda.

## Prasyarat
1. Hosting cPanel yang mendukung **Node.js** (Menu: "Setup Node.js App").
2. Database **MySQL** di cPanel.
3. Akses ke **File Manager** atau FTP.

---

## Langkah 1: Persiapan Database
1. Masuk ke cPanel dan buka menu **MySQL® Databases**.
2. Buat database baru (contoh: `stie_kemahasiswaan`).
3. Buat user database baru dan berikan hak akses penuh ke database tersebut. **Catat username dan password-nya.**
4. Buka **phpMyAdmin** dari cPanel.
5. Pilih database yang baru dibuat, lalu klik tab **Import**.
6. Unggah file `database.sql` yang ada di root folder proyek ini.

---

## Langkah 2: Persiapan File Proyek
1. Di lingkungan AI Studio ini, pastikan Anda telah menjalankan "Export to ZIP" dari menu Settings (atau download semua file).
2. Di komputer lokal Anda, lakukan instalasi dependensi dan build:
   ```bash
   npm install
   npm run build
   ```
3. Folder `dist` akan berisi aset frontend dan file `server.cjs` (backend yang sudah dibundel).

---

## Langkah 3: Mengunggah Proyek ke cPanel
1. Gunakan **File Manager** cPanel, masuk ke direktori aplikasi Anda (biasanya folder di luar `public_html` lebih aman, misal `/home/username/stie-app`).
2. Unggah file-file berikut ke folder tersebut:
   - `dist/` (seluruh folder)
   - `package.json`
   - `package-lock.json`
   - `.env` (Buat file baru, lihat Langkah 4)
   - `database.sql` (sebagai cadangan)

---

## Langkah 4: Konfigurasi Environment Variables (.env)
Buat file bernama `.env` di root folder aplikasi Anda di cPanel dengan isi sebagai berikut:
```env
# Database Configuration
DB_HOST=localhost
DB_USER=isi_username_db_cpanel
DB_PASSWORD=isi_password_db_cpanel
DB_NAME=isi_nama_db_cpanel

# Auth Configuration
JWT_SECRET=buat_string_acak_panjang_disini

# Node Environment
NODE_ENV=production
PORT=3000
```

---

## Langkah 5: Setup Node.js App di cPanel
1. Cari menu **Setup Node.js App** di cPanel.
2. Klik **Create Application**.
3. Isi kolom sebagai berikut:
   - **Node.js version**: Pilih versi terbaru (minimal 18+).
   - **Application mode**: Production.
   - **Application root**: Folder tempat Anda mengunggah file tadi (misal: `stie-app`).
   - **Application URL**: Domain atau subdomain Anda.
   - **Application startup file**: `dist/server.cjs`
4. Klik **Create**.
5. Setelah aplikasi dibuat, klik tombol **Run JS Install** untuk menginstal package yang dibutuhkan.
6. Klik **Restart** aplikasi.

---

## Tips & Troubleshooting
- **Module Native**: Aplikasi ini menggunakan `better-sqlite3` sebagai cadangan (fallback) saat di lingkugan preview. Jika Anda mengalami error saat `npm install` di cPanel (biasanya terkait node-gyp), Anda bisa menghapus `better-sqlite3` dari `package.json` dan menghapus referensi terkait di `server.ts` sebelum mem-build.
- **Penyimpanan Gambar**: Aplikasi saat ini menggunakan dummy images dari Picsum atau URL eksternal. Jika Anda ingin mengunggah gambar ke server sendiri, pastikan folder tujuan memiliki izin akses (permission) yang benar.
- **SSL**: Pastikan domain Anda sudah terpasang SSL (HTTPS) agar fitur login dan JWT bekerja dengan aman.
- **Port**: cPanel Node.js selector biasanya menangani port secara otomatis sehingga aplikasi akan dapat diakses langsung melalui domain Anda tanpa perlu mengetikkan `:3000`.

---
*Dibuat secara otomatis oleh AI Coding Assistant untuk STIE Eka Prasetya.*
