import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function start() {
  try {
    // Mencoba menjalankan server hasil build (dist/server.cjs)
    await import('./dist/server.cjs');
  } catch (err) {
    console.warn("Menjalankan mode fallback karena file dist/server.cjs belum ter-compile atau belum ada. Silakan jalankan 'npm run build' terlebih dahulu.");
    console.error("Detail Error:", err);
    
    // Loader cadangan (Express fallback) agar aplikasi tidak crash di cPanel
    try {
      const expressModule = await import('express');
      const express = expressModule.default;
      const app = express();
      
      app.all('*', (req, res) => {
        res.status(200).send(`
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="UTF-8">
            <title>Konfigurasi Node.js Berhasil</title>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; text-align: center; padding: 60px 20px; background: #fafafa; color: #333; }
              h1 { color: #d97706; margin-bottom: 8px; }
              .container { max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); text-align: left; }
              code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 14px; }
              ol { padding-left: 20px; line-height: 1.8; }
              li { margin-bottom: 12px; }
              .badge { background: #e0f2fe; color: #0369a1; padding: 4px 8px; border-radius: 6px; font-size: 13px; font-weight: bold; }
            </style>
          </head>
          <body>
            <div class="container">
              <h1>Selamat! Konfigurasi cPanel Berhasil 🚀</h1>
              <p style="color: #666; margin-bottom: 24px;">Node.js Selector Anda berhasil memuat file <code>app.js</code> tanpa ada crash.</p>
              
              <p><strong>Langkah berikutnya untuk menghidupkan aplikasi:</strong></p>
              <ol>
                <li>Pastikan Anda sudah mengklik tombol <strong style="color: #2563eb;">"Run NPM Install"</strong> di halaman Setup Node.js App.</li>
                <li>Gunakan menu <strong style="color: #2563eb;">"Run JS script"</strong> -> pilih <span class="badge">build</span> untuk melakukan kompilasi file server & client.</li>
                <li>Setelah kompilasi selesai (folder <code>dist</code> terbentuk), klik tombol <strong style="color: #16a34a;">"RESTART"</strong> di bagian atas halaman Node.js cPanel.</li>
              </ol>
              <hr style="border: 0; border-top: 1px solid #e5e7eb; margin: 24px 0;">
              <p style="font-size: 11px; color: #9ca3af; text-align: center;">Sistem Bootstrapper Aman - Mencegah "Unknown error occurred" akibat hilangnya file rilis.</p>
            </div>
          </body>
          </html>
        `);
      });
      
      const PORT = process.env.PORT || 3000;
      app.listen(PORT, '0.0.0.0', () => {
        console.log(`Fallback server running on port ${PORT}`);
      });
    } catch (e) {
      console.error("Gagal menjalankan fallback server karena express belum terinstall:", e);
    }
  }
}

start();
