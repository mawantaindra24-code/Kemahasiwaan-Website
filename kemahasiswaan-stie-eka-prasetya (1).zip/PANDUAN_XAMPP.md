# Panduan Uji Coba Lokal menggunakan XAMPP

Panduan ini akan membantu Anda menjalankan proyek **Kemahasiswaan STIE Eka Prasetya** di komputer lokal Anda menggunakan XAMPP sebagai server database (MySQL).

## Prasyarat
Sebelum memulai, pastikan Anda sudah menginstal:
1. **XAMPP**: Download di [apachefriends.org](https://www.apachefriends.org/).
2. **Node.js (LTS)**: Download di [nodejs.org](https://nodejs.org/). (Minimal versi 18).

---

## Langkah 1: Persiapan Database di XAMPP
1. Buka **XAMPP Control Panel**.
2. Klik tombol **Start** pada modul **MySQL** (Apache tidak wajib dijalankan jika hanya ingin menggunakan database-nya saja, tapi boleh dijalankan).
3. Klik tombol **Admin** pada modul MySQL untuk membuka **phpMyAdmin**.
4. Di phpMyAdmin:
   - Klik **Baru (New)** di panel kiri.
   - Beri nama database: `stie_kemahasiswaan` (atau nama lain).
   - Klik **Buat (Create)**.
5. Pilih database `stie_kemahasiswaan` yang baru dibuat.
6. Klik tab **Impor (Import)**.
7. Klik **Choose File** dan pilih file `database.sql` dari folder proyek Anda.
8. Klik **Go** di bagian bawah untuk mengeksekusi SQL.

---

## Langkah 2: Persiapan File Proyek
1. Download proyek ini (ZIP) atau Clone jika menggunakan Git.
2. Letakkan folder proyek di tempat yang mudah ditemukan (contoh: di Desktop atau dokumen Anda). **Tidak wajib** di dalam folder `htdocs` karena ini adalah aplikasi Node.js.

---

## Langkah 3: Konfigurasi Environment Variables (.env)
Buka folder proyek Anda dan buat file baru bernama `.env` (atau edit jika sudah ada) dengan konfigurasi berikut:

```env
# Database Configuration (XAMPP Default)
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=stie_kemahasiswaan

# Auth Configuration
JWT_SECRET=rahasia_uji_coba_stie

# Node Environment
NODE_ENV=development
PORT=3000
```

---

## Langkah 4: Menjalankan Aplikasi
1. Buka **Terminal** (CMD, PowerShell, atau Git Bash) di dalam folder proyek Anda.
2. Instal semua dependensi yang dibutuhkan:
   ```bash
   npm install
   ```
3. Jalankan aplikasi dalam mode pengembangan:
   ```bash
   npm run dev
   ```
4. Jika muncul tulisan `Server running on port 3000`, selamat! Aplikasi sudah berjalan.
5. Buka browser dan akses: `http://localhost:3000`

---

## Tips Login Admin
Gunakan akun default yang sudah ada di database:
- **Username**: `admin`
- **Password**: `admin123`

## Troubleshooting
- **Error: MySQL connection failed**: Pastikan MySQL di XAMPP sudah status "Running" (Hijau).
- **Port 3000 digunakan**: Jika port 3000 sudah dipakai aplikasi lain, Anda bisa mengubah `PORT=3001` di file `.env`.
- **Node.js tidak dikenali**: Pastikan Anda sudah menginstal Node.js dan merestart Terminal Anda.

---
*Dibuat untuk membantu tim IT STIE Eka Prasetya.*
