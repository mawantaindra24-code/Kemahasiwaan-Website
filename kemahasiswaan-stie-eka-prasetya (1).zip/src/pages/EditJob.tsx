import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { db, auth, storage } from '../lib/firebase';
import { doc, getDoc, updateDoc, collection, getDocs } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { JobVacancy } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft, Save, Briefcase, Building2, MapPin, Globe, Image as ImageIcon } from 'lucide-react';
import ReactQuill from 'react-quill-new';
import 'react-quill-new/dist/quill.snow.css';
import { motion } from 'motion/react';

export default function EditJob() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    company: '',
    location: '',
    type: 'Full-time' as 'Full-time' | 'Part-time' | 'Internship',
    description: '',
    link: '',
    imageUrl: ''
  });

  useEffect(() => {
    const fetchJob = async () => {
      if (!id) return;
      try {
        const jobDoc = await getDoc(doc(db, 'jobs', id));
        if (jobDoc.exists()) {
          const data = jobDoc.data() as JobVacancy;
          setFormData({
            title: data.title || '',
            company: data.company || '',
            location: data.location || '',
            type: data.type || 'Full-time',
            description: data.description || '',
            link: data.link || '',
            imageUrl: data.imageUrl || ''
          });
        } else {
          toast.error('Lowongan tidak ditemukan');
          navigate('/admin');
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `jobs/${id}`);
      } finally {
        setLoading(false);
      }
    };
    fetchJob();
  }, [id, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id) return;

    if (!formData.title || !formData.company || !formData.location) {
      toast.error('Harap isi semua field yang wajib (Posisi, Perusahaan, Lokasi)');
      return;
    }

    setSaving(true);
    try {
      await updateDoc(doc(db, 'jobs', id), {
        ...formData,
      });
      toast.success('Lowongan pekerjaan berhasil diperbarui');
      navigate('/admin');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `jobs/${id}`);
    } finally {
      setSaving(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Harap pilih file gambar (JPG, PNG, dll)');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error('Ukuran gambar terlalu besar (maksimal 2MB)');
      return;
    }

    setUploading(true);
    const toastId = toast.loading('Sedang mengunggah gambar...');

    try {
      const fileExtension = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${fileExtension}`;
      const storageRef = ref(storage, `jobs/${fileName}`);
      
      const uploadPromise = uploadBytes(storageRef, file).then(snapshot => getDownloadURL(snapshot.ref));
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('timeout')), 30000)
      );

      const downloadURL = await Promise.race([uploadPromise, timeoutPromise]) as string;
      
      setFormData(prev => ({ ...prev, imageUrl: downloadURL }));
      toast.success('Gambar berhasil diunggah', { id: toastId });
    } catch (error: any) {
      console.error('Upload error:', error);
      let errorMessage = 'Gagal mengunggah gambar';
      if (error.message === 'timeout') {
        errorMessage = 'Unggahan lambat atau terhenti. Silakan periksa koneksi internet.';
      }
      toast.error(errorMessage, { id: toastId });
    } finally {
      setUploading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto"
      >
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/admin')}
              className="rounded-full"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Edit Lowongan</h1>
              <p className="text-slate-500">Perbarui informasi peluang karir atau pelatihan</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => navigate('/admin')}>Batal</Button>
            <Button onClick={handleSubmit} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
              <Save className="h-4 w-4 mr-2" />
              {saving ? 'Menyimpan...' : 'Simpan Perubahan'}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>Detail Pekerjaan</CardTitle>
                <CardDescription>Informasi utama mengenai posisi yang ditawarkan</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Posisi / Jabatan</Label>
                  <Input 
                    id="title" 
                    placeholder="Contoh: Junior Web Developer" 
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    className="text-lg font-medium py-6"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="company">Nama Perusahaan / Instansi</Label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input 
                        id="company" 
                        placeholder="Nama perusahaan..." 
                        className="pl-10"
                        value={formData.company}
                        onChange={(e) => setFormData(prev => ({ ...prev, company: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Lokasi</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input 
                        id="location" 
                        placeholder="Contoh: Medan atau Remote" 
                        className="pl-10"
                        value={formData.location}
                        onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Deskripsi & Kualifikasi Singkat</Label>
                  <div className="bg-white rounded-md border border-slate-200 overflow-hidden">
                    <ReactQuill 
                      theme="snow"
                      value={formData.description}
                      onChange={(content) => setFormData(prev => ({ ...prev, description: content }))}
                      className="h-64"
                      placeholder="Tuliskan kualifikasi atau deskripsi lengkap mengenai pekerjaan ini..."
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>Tautan & Gambar</CardTitle>
                <CardDescription>Arahkan pelamar pada informasi lebih lanjut</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="imageUpload">Upload Gambar/Logo (Optional)</Label>
                    <Input 
                      id="imageUpload" 
                      type="file" 
                      accept="image/*"
                      onChange={handleFileChange}
                      disabled={uploading}
                      className="cursor-pointer"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="link">Link Pendaftaran (Optional)</Label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input 
                        id="link" 
                        placeholder="https://..." 
                        className="pl-10"
                        value={formData.link}
                        onChange={(e) => setFormData(prev => ({ ...prev, link: e.target.value }))}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="imageUrl">Atau gunakan URL Logo</Label>
                  <div className="relative">
                    <ImageIcon className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input 
                      id="imageUrl" 
                      placeholder="https://..." 
                      className="pl-10"
                      value={formData.imageUrl}
                      onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                    />
                  </div>
                </div>

                {formData.imageUrl && (
                  <div className="flex justify-center p-8 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                    <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col items-center">
                      <p className="text-[10px] uppercase font-bold text-slate-400 mb-3 tracking-wider">Preview Logo</p>
                      <img 
                        src={formData.imageUrl} 
                        alt="Logo Preview" 
                        className="h-24 w-24 object-contain"
                        referrerPolicy="no-referrer"
                        onError={(e) => (e.currentTarget.src = 'https://picsum.photos/seed/error/200/200')}
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Area */}
          <div className="space-y-8">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>Pengaturan Lowongan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="type">Tipe Pekerjaan</Label>
                  <Select 
                    value={formData.type} 
                    onValueChange={(val: any) => setFormData(prev => ({ ...prev, type: val }))}
                  >
                    <SelectTrigger id="type">
                      <SelectValue placeholder="Pilih tipe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Full-time">Full-time</SelectItem>
                      <SelectItem value="Part-time">Part-time</SelectItem>
                      <SelectItem value="Internship">Internship</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="bg-purple-50 p-6 rounded-xl border border-purple-100">
                  <div className="flex items-start gap-3 text-purple-900">
                    <Briefcase className="h-5 w-5 mt-1 shrink-0" />
                    <div>
                      <h4 className="font-semibold">Informasi Karir</h4>
                      <p className="text-sm text-purple-700 mt-1">
                        Lowongan yang Anda publikasikan akan muncul di halaman depan website dan dapat langsung dilihat oleh mahasiswa.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
