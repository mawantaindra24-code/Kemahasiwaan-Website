import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { db, auth } from '../lib/firebase';
import { updatePassword } from 'firebase/auth';
import { collection, addDoc, getDocs, deleteDoc, doc, updateDoc, serverTimestamp, query, orderBy } from 'firebase/firestore';
import { News, Category, GalleryItem, Event, Download, Announcement, SystemSettings, QuickLink, PartnerLogo, JobVacancy, TeamMember } from '../types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { Checkbox } from '../components/ui/checkbox';
import { toast } from 'sonner';
import { 
  Plus, 
  Trash2, 
  Edit, 
  Eye,
  Newspaper, 
  Image as ImageIcon, 
  Calendar, 
  Download as DownloadIcon, 
  Tags,
  LayoutDashboard,
  LogOut,
  Bell,
  AlertTriangle,
  Settings,
  Link as LinkIcon,
  Briefcase,
  Lock
} from 'lucide-react';
import { formatSafeDate } from '../lib/utils';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

export default function AdminDashboard() {
  const { logout } = useAuth();
  const [news, setNews] = useState<News[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [downloads, setDownloads] = useState<Download[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [quickLinks, setQuickLinks] = useState<QuickLink[]>([]);
  const [partnerLogos, setPartnerLogos] = useState<PartnerLogo[]>([]);
  const [jobs, setJobs] = useState<JobVacancy[]>([]);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [editingTeamMember, setEditingTeamMember] = useState<TeamMember | null>(null);

  // Password setting states
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);

  // Form states
  const [newCategory, setNewCategory] = useState({ name: '', slug: '' });
  const [newGallery, setNewGallery] = useState({ title: '', imageUrl: '' });
  const [newEvent, setNewEvent] = useState({ title: '', date: '', location: '', description: '', whatsapp: '' });
  const [newDownload, setNewDownload] = useState({ title: '', fileUrl: '', category: '' });
  const [newAnnouncement, setNewAnnouncement] = useState({ title: '', content: '', isActive: true, isUrgent: false, deadline: '' });
  const [newQuickLink, setNewQuickLink] = useState({ title: '', url: '', order: 0 });
  const [newPartnerLogo, setNewPartnerLogo] = useState({ name: '', imageUrl: '', order: 0 });
  const [newJob, setNewJob] = useState({ title: '', company: '', location: '', type: 'Full-time' as const, description: '', link: '', imageUrl: '' });
  const [newTeamMember, setNewTeamMember] = useState({ name: '', position: '', imageUrl: '', whatsapp: '', order: 0 });
  const [settingsForm, setSettingsForm] = useState({
    heroTitle: '',
    heroSubtitle: '',
    heroImageUrl: '',
    footerDescription: '',
    address: '',
    phone: '',
    email: '',
    whatsappNumber: '',
    whatsappMessage: '',
    facebookUrl: '',
    instagramUrl: '',
    youtubeUrl: ''
  });

  const [deleteConfirm, setDeleteConfirm] = useState<{ coll: string, id: string } | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const newsSnap = await getDocs(query(collection(db, 'news'), orderBy('createdAt', 'desc')));
      setNews(newsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as News)));

      const catSnap = await getDocs(collection(db, 'categories'));
      setCategories(catSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category)));

      const gallerySnap = await getDocs(query(collection(db, 'gallery'), orderBy('createdAt', 'desc')));
      setGallery(gallerySnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as GalleryItem)));

      const eventsSnap = await getDocs(query(collection(db, 'events'), orderBy('date', 'asc')));
      setEvents(eventsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Event)));

      const downloadsSnap = await getDocs(query(collection(db, 'downloads'), orderBy('createdAt', 'desc')));
      setDownloads(downloadsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Download)));

      const announcementsSnap = await getDocs(query(collection(db, 'announcements'), orderBy('createdAt', 'desc')));
      setAnnouncements(announcementsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Announcement)));

      const quickLinksSnap = await getDocs(query(collection(db, 'quickLinks'), orderBy('order', 'asc')));
      setQuickLinks(quickLinksSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as QuickLink)));

      const logosSnap = await getDocs(query(collection(db, 'partnerLogos'), orderBy('order', 'asc')));
      setPartnerLogos(logosSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as PartnerLogo)));

      const jobsSnap = await getDocs(query(collection(db, 'jobs'), orderBy('createdAt', 'desc')));
      setJobs(jobsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as JobVacancy)));

      const teamSnap = await getDocs(query(collection(db, 'team'), orderBy('order', 'asc')));
      setTeam(teamSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as TeamMember)));

      const settingsSnap = await getDocs(collection(db, 'settings'));
      if (!settingsSnap.empty) {
        const settingsData = { id: settingsSnap.docs[0].id, ...settingsSnap.docs[0].data() } as SystemSettings;
        setSettings(settingsData);
        setSettingsForm({
          heroTitle: settingsData.heroTitle || '',
          heroSubtitle: settingsData.heroSubtitle || '',
          heroImageUrl: settingsData.heroImageUrl || '',
          footerDescription: settingsData.footerDescription || '',
          address: settingsData.address || '',
          phone: settingsData.phone || '',
          email: settingsData.email || '',
          whatsappNumber: settingsData.whatsappNumber || '',
          whatsappMessage: settingsData.whatsappMessage || '',
          facebookUrl: settingsData.facebookUrl || '',
          instagramUrl: settingsData.instagramUrl || '',
          youtubeUrl: settingsData.youtubeUrl || ''
        });
      }
    } catch (error) {
      console.error('Error fetching admin data:', error);
      toast.error('Gagal mengambil data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'categories'), newCategory);
      toast.success('Kategori berhasil ditambahkan');
      setNewCategory({ name: '', slug: '' });
      fetchData();
    } catch (error) {
      console.error('Error adding category:', error);
      toast.error('Gagal menambahkan kategori');
    }
  };

  const handleUpdateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory) return;
    try {
      await updateDoc(doc(db, 'categories', editingCategory.id), {
        name: editingCategory.name,
        slug: editingCategory.slug
      });
      toast.success('Kategori berhasil diperbarui');
      setEditingCategory(null);
      fetchData();
    } catch (error) {
      toast.error('Gagal memperbarui kategori');
    }
  };

  const handleAddGallery = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'gallery'), {
        ...newGallery,
        createdAt: serverTimestamp(),
      });
      toast.success('Foto berhasil ditambahkan');
      setNewGallery({ title: '', imageUrl: '' });
      fetchData();
    } catch (error) {
      toast.error('Gagal menambahkan foto');
    }
  };

  const handleAddEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'events'), {
        ...newEvent,
        date: new Date(newEvent.date),
        createdAt: serverTimestamp(),
      });
      toast.success('Agenda berhasil ditambahkan');
      setNewEvent({ title: '', date: '', location: '', description: '', whatsapp: '' });
      fetchData();
    } catch (error) {
      toast.error('Gagal menambahkan agenda');
    }
  };

  const handleUpdateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEvent) return;
    try {
      await updateDoc(doc(db, 'events', editingEvent.id), {
        title: editingEvent.title,
        date: new Date(editingEvent.date as any),
        location: editingEvent.location,
        description: editingEvent.description,
        whatsapp: editingEvent.whatsapp || '',
        updatedAt: serverTimestamp(),
      });
      toast.success('Agenda berhasil diperbarui');
      setEditingEvent(null);
      fetchData();
    } catch (error) {
      toast.error('Gagal memperbarui agenda');
    }
  };

  const handleAddDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'downloads'), {
        ...newDownload,
        createdAt: serverTimestamp(),
      });
      toast.success('File berhasil ditambahkan');
      setNewDownload({ title: '', fileUrl: '', category: '' });
      fetchData();
    } catch (error) {
      toast.error('Gagal menambahkan file');
    }
  };

  const handleAddAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'announcements'), {
        ...newAnnouncement,
        deadline: newAnnouncement.deadline ? new Date(newAnnouncement.deadline) : null,
        createdAt: serverTimestamp(),
      });
      toast.success('Pengumuman berhasil ditambahkan');
      setNewAnnouncement({ title: '', content: '', isActive: true, isUrgent: false, deadline: '' });
      fetchData();
    } catch (error) {
      toast.error('Gagal menambahkan pengumuman');
    }
  };

  const handleUpdateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAnnouncement) return;
    try {
      await updateDoc(doc(db, 'announcements', editingAnnouncement.id), {
        title: editingAnnouncement.title,
        content: editingAnnouncement.content,
        isActive: editingAnnouncement.isActive,
        isUrgent: editingAnnouncement.isUrgent,
        deadline: editingAnnouncement.deadline ? new Date(editingAnnouncement.deadline as any) : null,
        updatedAt: serverTimestamp()
      });
      toast.success('Pengumuman berhasil diperbarui');
      setEditingAnnouncement(null);
      fetchData();
    } catch (error) {
      toast.error('Gagal memperbarui pengumuman');
    }
  };

  const toggleAnnouncementStatus = async (id: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, 'announcements', id), {
        isActive: !currentStatus
      });
      toast.success('Status pengumuman diperbarui');
      fetchData();
    } catch (error) {
      toast.error('Gagal memperbarui status');
    }
  };

  const handleDelete = (coll: string, id: string) => {
    setDeleteConfirm({ coll, id });
  };

  const confirmDelete = async () => {
    if (!deleteConfirm) return;
    
    try {
      await deleteDoc(doc(db, deleteConfirm.coll, deleteConfirm.id));
      toast.success('Data berhasil dihapus');
      setDeleteConfirm(null);
      fetchData();
    } catch (error) {
      toast.error('Gagal menghapus data');
    }
  };

  const handleUpdateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (settings?.id) {
        await updateDoc(doc(db, 'settings', settings.id), {
          ...settingsForm,
          updatedAt: serverTimestamp()
        });
      } else {
        await addDoc(collection(db, 'settings'), {
          ...settingsForm,
          updatedAt: serverTimestamp()
        });
      }
      toast.success('Pengaturan sistem berhasil diperbarui');
      fetchData();
    } catch (error) {
      console.error('Error updating settings:', error);
      toast.error('Gagal memperbarui pengaturan');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.error('Password baru dan konfirmasi password tidak cocok.');
      return;
    }
    if (newPassword.length < 6) {
      toast.error('Password baru harus minimal 6 karakter.');
      return;
    }
    setPasswordLoading(true);
    try {
      if (auth.currentUser) {
        await updatePassword(auth.currentUser, newPassword);
        toast.success('Password admin berhasil diperbarui di Firebase Auth.');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        toast.error('Tidak ada admin yang sedang aktif login.');
      }
    } catch (error: any) {
      if (error.code === 'auth/requires-recent-login') {
        toast.error('Sesi keamanan habis. Harap logout lalu masuk kembali sebelum mengganti password.');
      } else {
        toast.error(error.message || 'Gagal memperbarui password.');
      }
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleAddQuickLink = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'quickLinks'), {
        ...newQuickLink,
        createdAt: serverTimestamp()
      });
      toast.success('Tautan cepat berhasil ditambahkan');
      setNewQuickLink({ title: '', url: '', order: 0 });
      fetchData();
    } catch (error) {
      console.error('Error adding quick link:', error);
      toast.error('Gagal menambahkan tautan');
    }
  };

  const handleAddPartnerLogo = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'partnerLogos'), {
        ...newPartnerLogo,
        createdAt: serverTimestamp()
      });
      toast.success('Logo partner berhasil ditambahkan');
      setNewPartnerLogo({ name: '', imageUrl: '', order: 0 });
      fetchData();
    } catch (error) {
      console.error('Error adding partner logo:', error);
      toast.error('Gagal menambahkan logo');
    }
  };

  const handleAddJob = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'jobs'), {
        ...newJob,
        createdAt: serverTimestamp()
      });
      toast.success('Lowongan berhasil ditambahkan');
      setNewJob({ title: '', company: '', location: '', type: 'Full-time', description: '', link: '', imageUrl: '' });
      fetchData();
    } catch (error) {
      console.error('Error adding job:', error);
      toast.error('Gagal menambahkan lowongan');
    }
  };

  const handleAddTeamMember = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'team'), {
        ...newTeamMember,
        createdAt: serverTimestamp()
      });
      toast.success('Anggota tim berhasil ditambahkan');
      setNewTeamMember({ name: '', position: '', imageUrl: '', whatsapp: '', order: 0 });
      fetchData();
    } catch (error) {
      console.error('Error adding team member:', error);
      toast.error('Gagal menambahkan anggota tim');
    }
  };

  const handleUpdateTeamMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTeamMember) return;
    try {
      await updateDoc(doc(db, 'team', editingTeamMember.id), {
        name: editingTeamMember.name,
        position: editingTeamMember.position,
        imageUrl: editingTeamMember.imageUrl || '',
        whatsapp: editingTeamMember.whatsapp || '',
        order: editingTeamMember.order,
        updatedAt: serverTimestamp()
      });
      toast.success('Informasi anggota tim berhasil diperbarui');
      setEditingTeamMember(null);
      fetchData();
    } catch (error) {
      console.error('Error updating team member:', error);
      toast.error('Gagal memperbarui informasi anggota tim');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-4">
          <div className="bg-blue-600 p-2 rounded-lg">
            <LayoutDashboard className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Dashboard Admin</h1>
            <p className="text-slate-500">Kelola konten kemahasiswaan STIE Eka Prasetya</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
          onClick={() => logout()}
        >
          <LogOut className="h-4 w-4 mr-2" /> Keluar
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-8">
        <TabsList className="bg-white border border-slate-200 p-1 h-auto flex flex-wrap gap-1">
          <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <LayoutDashboard className="h-4 w-4 mr-2" /> Ringkasan
          </TabsTrigger>
          <TabsTrigger value="news" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <Newspaper className="h-4 w-4 mr-2" /> Berita
          </TabsTrigger>
          <TabsTrigger value="categories" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <Tags className="h-4 w-4 mr-2" /> Kategori
          </TabsTrigger>
          <TabsTrigger value="gallery" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <ImageIcon className="h-4 w-4 mr-2" /> Galeri
          </TabsTrigger>
          <TabsTrigger value="events" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <Calendar className="h-4 w-4 mr-2" /> Agenda
          </TabsTrigger>
          <TabsTrigger value="downloads" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <DownloadIcon className="h-4 w-4 mr-2" /> Download
          </TabsTrigger>
          <TabsTrigger value="announcements" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <Bell className="h-4 w-4 mr-2" /> Pengumuman
          </TabsTrigger>
          <TabsTrigger value="jobs" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <Briefcase className="h-4 w-4 mr-2" /> Lowongan
          </TabsTrigger>
          <TabsTrigger value="team" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <Plus className="h-4 w-4 mr-2" /> Anggota Tim
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <Settings className="h-4 w-4 mr-2" /> Pengaturan
          </TabsTrigger>
          <TabsTrigger value="password" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white px-4 py-2">
            <Lock className="h-4 w-4 mr-2" /> Atur Password
          </TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <Card className="bg-blue-50 border-blue-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-blue-600">Total Berita</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-900">{news.length}</div>
                <p className="text-xs text-blue-500 mt-1">Artikel terpublikasi</p>
              </CardContent>
            </Card>
            <Card className="bg-emerald-50 border-emerald-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-emerald-600">Total Galeri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-emerald-900">{gallery.length}</div>
                <p className="text-xs text-emerald-500 mt-1">Foto kegiatan</p>
              </CardContent>
            </Card>
            <Card className="bg-amber-50 border-amber-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-amber-600">Agenda Aktif</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-900">{events.length}</div>
                <p className="text-xs text-amber-500 mt-1">Event mendatang</p>
              </CardContent>
            </Card>
            <Card className="bg-slate-50 border-slate-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">File Download</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-slate-900">{downloads.length}</div>
                <p className="text-xs text-slate-500 mt-1">Dokumen tersedia</p>
              </CardContent>
            </Card>
            <Card className="bg-purple-50 border-purple-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-purple-600">Total Lowongan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-900">{jobs.length}</div>
                <p className="text-xs text-purple-500 mt-1">Peluang karir</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Berita Terbaru</CardTitle>
                <CardDescription>5 berita terakhir yang diunggah</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {news.slice(0, 5).map(item => (
                    <div key={item.id} className="flex items-center justify-between border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                      <div>
                        <p className="font-medium text-slate-900 line-clamp-1">{item.title}</p>
                        <p className="text-xs text-slate-500">{formatSafeDate(item.createdAt, 'dd MMM yyyy')}</p>
                      </div>
                      <div className="bg-blue-100 text-blue-700 text-[10px] px-2 py-0.5 rounded-full font-medium">
                        {categories.find(c => c.id === item.categoryId)?.name || 'Umum'}
                      </div>
                    </div>
                  ))}
                  {news.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Belum ada berita</p>}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Agenda Mendatang</CardTitle>
                <CardDescription>Jadwal kegiatan kampus terdekat</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {events.slice(0, 5).map(item => (
                    <div key={item.id} className="flex items-center gap-3 border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                      <div className="bg-amber-100 text-amber-700 p-2 rounded flex flex-col items-center min-w-[50px]">
                        <span className="text-xs font-bold">{formatSafeDate(item.date, 'dd')}</span>
                        <span className="text-[10px] uppercase">{formatSafeDate(item.date, 'MMM')}</span>
                      </div>
                      <div>
                        <p className="font-medium text-slate-900 line-clamp-1">{item.title}</p>
                        <p className="text-xs text-slate-500">{item.location}</p>
                      </div>
                    </div>
                  ))}
                  {events.length === 0 && <p className="text-sm text-slate-500 text-center py-4">Belum ada agenda</p>}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* News Tab */}
        <TabsContent value="news" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Daftar Berita</h2>
            <Link to="/admin/news/add">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" /> Tambah Berita
              </Button>
            </Link>
          </div>

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Judul</TableHead>
                  <TableHead>Kategori</TableHead>
                  <TableHead>Tipe</TableHead>
                  <TableHead>Tanggal</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {news.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.title}</TableCell>
                    <TableCell>{categories.find(c => c.id === item.categoryId)?.name}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {item.isPrestasi && <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-600 border-amber-100">Prestasi</Badge>}
                        {item.isKemahasiswaan && <Badge variant="outline" className="text-[10px] bg-blue-50 text-blue-600 border-blue-100">Mhs</Badge>}
                        {item.isEvent && <Badge variant="outline" className="text-[10px] bg-purple-50 text-purple-600 border-purple-100">Event</Badge>}
                      </div>
                    </TableCell>
                    <TableCell>{formatSafeDate(item.createdAt, 'dd/MM/yyyy')}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" render={
                          <Link to={`/news/${item.id}`}>
                            <Eye className="h-4 w-4 text-slate-500" />
                          </Link>
                        } />
                        <Button variant="ghost" size="icon" render={
                          <Link to={`/admin/news/edit/${item.id}`}>
                            <Edit className="h-4 w-4 text-blue-500" />
                          </Link>
                        } />
                        <Button variant="ghost" size="icon" onClick={() => handleDelete('news', item.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Kategori Berita</h2>
            <Dialog>
              <DialogTrigger nativeButton render={<Button className="bg-blue-600 hover:bg-blue-700"><Plus className="h-4 w-4 mr-2" /> Tambah Kategori</Button>} />
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Tambah Kategori</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddCategory} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Nama Kategori</Label>
                    <Input 
                      required 
                      value={newCategory.name} 
                      onChange={e => setNewCategory({...newCategory, name: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Slug (URL Friendly)</Label>
                    <Input 
                      required 
                      value={newCategory.slug} 
                      onChange={e => setNewCategory({...newCategory, slug: e.target.value.toLowerCase().replace(/\s+/g, '-')})} 
                    />
                  </div>
                  <Button type="submit" className="w-full bg-blue-600">Simpan Kategori</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nama</TableHead>
                  <TableHead>Slug</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((cat) => (
                  <TableRow key={cat.id}>
                    <TableCell className="font-medium">{cat.name}</TableCell>
                    <TableCell>{cat.slug}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Dialog>
                          <DialogTrigger nativeButton render={
                            <Button variant="ghost" size="icon" onClick={() => setEditingCategory(cat)}>
                              <Edit className="h-4 w-4 text-blue-500" />
                            </Button>
                          } />
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Edit Kategori</DialogTitle>
                            </DialogHeader>
                            {editingCategory && (
                              <form onSubmit={handleUpdateCategory} className="space-y-4">
                                <div className="space-y-2">
                                  <Label>Nama Kategori</Label>
                                  <Input 
                                    required 
                                    value={editingCategory.name} 
                                    onChange={e => setEditingCategory({...editingCategory, name: e.target.value})} 
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Slug (URL Friendly)</Label>
                                  <Input 
                                    required 
                                    value={editingCategory.slug} 
                                    onChange={e => setEditingCategory({...editingCategory, slug: e.target.value.toLowerCase().replace(/\s+/g, '-')})} 
                                  />
                                </div>
                                <Button type="submit" className="w-full bg-blue-600">Simpan Perubahan</Button>
                              </form>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete('categories', cat.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* Gallery Tab */}
        <TabsContent value="gallery" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Galeri Foto</h2>
            <Dialog>
              <DialogTrigger nativeButton render={<Button className="bg-blue-600 hover:bg-blue-700"><Plus className="h-4 w-4 mr-2" /> Tambah Foto</Button>} />
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Tambah Foto Galeri</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddGallery} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Judul Foto</Label>
                    <Input 
                      required 
                      value={newGallery.title} 
                      onChange={e => setNewGallery({...newGallery, title: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>URL Gambar</Label>
                    <Input 
                      required 
                      value={newGallery.imageUrl} 
                      onChange={e => setNewGallery({...newGallery, imageUrl: e.target.value})} 
                    />
                  </div>
                  <Button type="submit" className="w-full bg-blue-600">Simpan Foto</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {gallery.map((item) => (
              <Card key={item.id} className="overflow-hidden group relative">
                <img src={item.imageUrl} alt={item.title} className="aspect-square object-cover" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-4 text-center">
                  <p className="text-white text-xs font-medium mb-2">{item.title}</p>
                  <Button variant="destructive" size="icon" onClick={() => handleDelete('gallery', item.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Events Tab */}
        <TabsContent value="events" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Agenda Kampus</h2>
            <Dialog>
              <DialogTrigger nativeButton render={<Button className="bg-blue-600 hover:bg-blue-700"><Plus className="h-4 w-4 mr-2" /> Tambah Agenda</Button>} />
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Tambah Agenda Baru</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddEvent} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Nama Agenda</Label>
                    <Input 
                      required 
                      value={newEvent.title} 
                      onChange={e => setNewEvent({...newEvent, title: e.target.value})} 
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Tanggal</Label>
                      <Input 
                        required 
                        type="datetime-local" 
                        value={newEvent.date} 
                        onChange={e => setNewEvent({...newEvent, date: e.target.value})} 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Lokasi</Label>
                      <Input 
                        required 
                        value={newEvent.location} 
                        onChange={e => setNewEvent({...newEvent, location: e.target.value})} 
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Deskripsi Singkat</Label>
                    <Textarea 
                      value={newEvent.description} 
                      onChange={e => setNewEvent({...newEvent, description: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Nomor WhatsApp (Contact Person)</Label>
                    <Input 
                      placeholder="Contoh: 628123456789"
                      value={newEvent.whatsapp} 
                      onChange={e => setNewEvent({...newEvent, whatsapp: e.target.value})} 
                    />
                  </div>
                  <Button type="submit" className="w-full bg-blue-600">Simpan Agenda</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Agenda</TableHead>
                  <TableHead>Tanggal</TableHead>
                  <TableHead>Lokasi</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {events.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.title}</TableCell>
                    <TableCell>{formatSafeDate(item.date, 'dd/MM/yyyy HH:mm')}</TableCell>
                    <TableCell>{item.location}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Dialog>
                          <DialogTrigger nativeButton render={
                            <Button variant="ghost" size="icon" onClick={() => setEditingEvent({
                              ...item,
                              date: formatSafeDate(item.date, "yyyy-MM-dd'T'HH:mm") as any
                            })}>
                              <Edit className="h-4 w-4 text-blue-500" />
                            </Button>
                          } />
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Edit Agenda</DialogTitle>
                            </DialogHeader>
                            {editingEvent && (
                              <form onSubmit={handleUpdateEvent} className="space-y-4">
                                <div className="space-y-2">
                                  <Label>Nama Agenda</Label>
                                  <Input 
                                    required 
                                    value={editingEvent.title} 
                                    onChange={e => setEditingEvent({...editingEvent, title: e.target.value})} 
                                  />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                    <Label>Tanggal</Label>
                                    <Input 
                                      required 
                                      type="datetime-local" 
                                      value={editingEvent.date as any} 
                                      onChange={e => setEditingEvent({...editingEvent, date: e.target.value as any})} 
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Lokasi</Label>
                                    <Input 
                                      required 
                                      value={editingEvent.location} 
                                      onChange={e => setEditingEvent({...editingEvent, location: e.target.value})} 
                                    />
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <Label>Deskripsi Singkat</Label>
                                  <Textarea 
                                    value={editingEvent.description} 
                                    onChange={e => setEditingEvent({...editingEvent, description: e.target.value})} 
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Nomor WhatsApp (Contact Person)</Label>
                                  <Input 
                                    placeholder="Contoh: 628123456789"
                                    value={editingEvent.whatsapp || ''} 
                                    onChange={e => setEditingEvent({...editingEvent, whatsapp: e.target.value})} 
                                  />
                                </div>
                                <Button type="submit" className="w-full bg-blue-600">Simpan Perubahan</Button>
                              </form>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete('events', item.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* Downloads Tab */}
        <TabsContent value="downloads" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Pusat Download</h2>
            <Dialog>
              <DialogTrigger nativeButton render={<Button className="bg-blue-600 hover:bg-blue-700"><Plus className="h-4 w-4 mr-2" /> Tambah File</Button>} />
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Tambah File Download</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddDownload} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Nama File</Label>
                    <Input 
                      required 
                      value={newDownload.title} 
                      onChange={e => setNewDownload({...newDownload, title: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>URL File</Label>
                    <Input 
                      required 
                      value={newDownload.fileUrl} 
                      onChange={e => setNewDownload({...newDownload, fileUrl: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Kategori File</Label>
                    <Input 
                      required 
                      value={newDownload.category} 
                      onChange={e => setNewDownload({...newDownload, category: e.target.value})} 
                      placeholder="Misal: Form, Panduan, Beasiswa"
                    />
                  </div>
                  <Button type="submit" className="w-full bg-blue-600">Simpan File</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nama File</TableHead>
                  <TableHead>Kategori</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {downloads.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.title}</TableCell>
                    <TableCell>{item.category}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => handleDelete('downloads', item.id)}>
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
        {/* Announcements Tab */}
        <TabsContent value="announcements" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Daftar Pengumuman</h2>
            <Dialog>
              <DialogTrigger nativeButton render={<Button className="bg-blue-600 hover:bg-blue-700"><Plus className="h-4 w-4 mr-2" /> Tambah Pengumuman</Button>} />
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Tambah Pengumuman Baru</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddAnnouncement} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Judul Pengumuman</Label>
                    <Input 
                      required 
                      value={newAnnouncement.title} 
                      onChange={e => setNewAnnouncement({...newAnnouncement, title: e.target.value})} 
                      placeholder="Masukkan judul pengumuman"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Isi Pengumuman</Label>
                    <Textarea 
                      required 
                      value={newAnnouncement.content} 
                      onChange={e => setNewAnnouncement({...newAnnouncement, content: e.target.value})} 
                      placeholder="Masukkan isi pengumuman"
                      rows={4}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Deadline / Batas Waktu (Opsional)</Label>
                    <Input 
                      type="date"
                      value={newAnnouncement.deadline} 
                      onChange={e => setNewAnnouncement({...newAnnouncement, deadline: e.target.value})} 
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="isUrgent" 
                      checked={newAnnouncement.isUrgent}
                      onCheckedChange={(checked) => setNewAnnouncement({...newAnnouncement, isUrgent: checked as boolean})}
                    />
                    <Label htmlFor="isUrgent" className="text-sm font-medium cursor-pointer">Tandai sebagai Penting/Urgent</Label>
                  </div>
                  <Button type="submit" className="w-full bg-blue-600">Simpan Pengumuman</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Judul</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Tipe</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead>Tgl Dibuat</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {announcements.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">
                      <div className="flex flex-col">
                        <span>{item.title}</span>
                        <span className="text-xs text-slate-500 line-clamp-1">{item.content}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={item.isActive ? "default" : "secondary"}
                        className="cursor-pointer"
                        onClick={() => toggleAnnouncementStatus(item.id, item.isActive)}
                      >
                        {item.isActive ? 'Aktif' : 'Nonaktif'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {item.isUrgent && <Badge variant="destructive">Urgent</Badge>}
                    </TableCell>
                    <TableCell>
                      {item.deadline ? (
                        <div className="flex items-center gap-1.5 text-red-600 font-semibold">
                          <AlertTriangle className="h-3 w-3" />
                          {formatSafeDate(item.deadline, 'dd/MM/yyyy')}
                        </div>
                      ) : '-'}
                    </TableCell>
                    <TableCell>{formatSafeDate(item.createdAt, 'dd/MM/yyyy')}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Dialog>
                          <DialogTrigger nativeButton render={
                            <Button variant="ghost" size="icon" onClick={() => setEditingAnnouncement({
                              ...item,
                              deadline: (item.deadline ? formatSafeDate(item.deadline, 'yyyy-MM-dd') : '') as any
                            })}>
                              <Edit className="h-4 w-4 text-blue-500" />
                            </Button>
                          } />
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Edit Pengumuman</DialogTitle>
                            </DialogHeader>
                            {editingAnnouncement && (
                              <form onSubmit={handleUpdateAnnouncement} className="space-y-4">
                                <div className="space-y-2">
                                  <Label>Judul Pengumuman</Label>
                                  <Input 
                                    required 
                                    value={editingAnnouncement.title} 
                                    onChange={e => setEditingAnnouncement({...editingAnnouncement, title: e.target.value})} 
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Isi Pengumuman</Label>
                                  <Textarea 
                                    required 
                                    value={editingAnnouncement.content} 
                                    onChange={e => setEditingAnnouncement({...editingAnnouncement, content: e.target.value})} 
                                    rows={4}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Deadline / Batas Waktu (Opsional)</Label>
                                  <Input 
                                    type="date"
                                    value={editingAnnouncement.deadline as any} 
                                    onChange={e => setEditingAnnouncement({...editingAnnouncement, deadline: e.target.value as any})} 
                                  />
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Checkbox 
                                    id="editIsUrgent" 
                                    checked={editingAnnouncement.isUrgent}
                                    onCheckedChange={(checked) => setEditingAnnouncement({...editingAnnouncement, isUrgent: checked as boolean})}
                                  />
                                  <Label htmlFor="editIsUrgent" className="text-sm font-medium cursor-pointer">Tandai sebagai Penting/Urgent</Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Checkbox 
                                    id="editIsActive" 
                                    checked={editingAnnouncement.isActive}
                                    onCheckedChange={(checked) => setEditingAnnouncement({...editingAnnouncement, isActive: checked as boolean})}
                                  />
                                  <Label htmlFor="editIsActive" className="text-sm font-medium cursor-pointer">Aktifkan Pengumuman</Label>
                                </div>
                                <Button type="submit" className="w-full bg-blue-600">Simpan Perubahan</Button>
                              </form>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete('announcements', item.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {announcements.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-10 text-slate-500">
                      Belum ada pengumuman
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* Jobs Tab */}
        <TabsContent value="jobs" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Lowongan Pelatihan & Pekerjaan</h2>
            <Link to="/admin/jobs/add">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" /> Tambah Lowongan
              </Button>
            </Link>
          </div>

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Posisi</TableHead>
                  <TableHead>Perusahaan</TableHead>
                  <TableHead>Tipe</TableHead>
                  <TableHead>Tanggal</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {jobs.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">
                      <div className="flex flex-col">
                        <span>{item.title}</span>
                        <span className="text-xs text-slate-500">{item.location}</span>
                      </div>
                    </TableCell>
                    <TableCell>{item.company}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[10px] font-medium">
                        {item.type}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatSafeDate(item.createdAt, 'dd/MM/yyyy')}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Link to={`/admin/jobs/edit/${item.id}`}>
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4 text-blue-500" />
                          </Button>
                        </Link>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete('jobs', item.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {jobs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-10 text-slate-500">
                      Belum ada lowongan pekerjaan
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* Team Tab */}
        <TabsContent value="team" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Struktur Organisasi / Tim</h2>
            <Dialog>
              <DialogTrigger nativeButton render={<Button className="bg-blue-600 hover:bg-blue-700"><Plus className="h-4 w-4 mr-2" /> Tambah Anggota</Button>} />
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Tambah Anggota Tim</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddTeamMember} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Nama Lengkap</Label>
                    <Input 
                      required 
                      value={newTeamMember.name} 
                      onChange={e => setNewTeamMember({...newTeamMember, name: e.target.value})} 
                      placeholder="Masukkan nama lengkap"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Jabatan / Posisi</Label>
                    <Input 
                      required 
                      value={newTeamMember.position} 
                      onChange={e => setNewTeamMember({...newTeamMember, position: e.target.value})} 
                      placeholder="Contoh: Ketua BEM, Kepala Bagian"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>URL Foto Profil (Opsional)</Label>
                    <Input 
                      value={newTeamMember.imageUrl} 
                      onChange={e => setNewTeamMember({...newTeamMember, imageUrl: e.target.value})} 
                      placeholder="https://..."
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>No. WhatsApp (Opsional)</Label>
                    <Input 
                      value={newTeamMember.whatsapp} 
                      onChange={e => setNewTeamMember({...newTeamMember, whatsapp: e.target.value})} 
                      placeholder="Contoh: 628123456789"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>No. Urut (Untuk Pengurutan)</Label>
                    <Input 
                      type="number"
                      required 
                      value={newTeamMember.order} 
                      onChange={e => setNewTeamMember({...newTeamMember, order: parseInt(e.target.value)})} 
                    />
                  </div>
                  <Button type="submit" className="w-full bg-blue-600">Simpan Anggota</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Foto</TableHead>
                  <TableHead>Nama</TableHead>
                  <TableHead>Jabatan</TableHead>
                  <TableHead>Urutan</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {team.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell>
                      <div className="h-10 w-10 rounded-full overflow-hidden bg-slate-100 border border-slate-200">
                        {member.imageUrl ? (
                          <img src={member.imageUrl} alt={member.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="h-full w-full flex items-center justify-center text-slate-300 font-bold text-xs">
                            {member.name?.[0] || 'T'}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{member.name}</TableCell>
                    <TableCell>{member.position}</TableCell>
                    <TableCell>{member.order}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Dialog>
                          <DialogTrigger nativeButton render={
                            <Button variant="ghost" size="icon" onClick={() => setEditingTeamMember(member)}>
                              <Edit className="h-4 w-4 text-blue-500" />
                            </Button>
                          } />
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Edit Anggota Tim</DialogTitle>
                            </DialogHeader>
                            {editingTeamMember && (
                              <form onSubmit={handleUpdateTeamMember} className="space-y-4">
                                <div className="space-y-2">
                                  <Label>Nama Lengkap</Label>
                                  <Input 
                                    required 
                                    value={editingTeamMember.name} 
                                    onChange={e => setEditingTeamMember({...editingTeamMember, name: e.target.value})} 
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Jabatan / Posisi</Label>
                                  <Input 
                                    required 
                                    value={editingTeamMember.position} 
                                    onChange={e => setEditingTeamMember({...editingTeamMember, position: e.target.value})} 
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>URL Foto Profil</Label>
                                  <Input 
                                    value={editingTeamMember.imageUrl || ''} 
                                    onChange={e => setEditingTeamMember({...editingTeamMember, imageUrl: e.target.value})} 
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>No. WhatsApp</Label>
                                  <Input 
                                    value={editingTeamMember.whatsapp || ''} 
                                    onChange={e => setEditingTeamMember({...editingTeamMember, whatsapp: e.target.value})} 
                                    placeholder="Contoh: 628123456789"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>No. Urut</Label>
                                  <Input 
                                    type="number"
                                    required 
                                    value={editingTeamMember.order} 
                                    onChange={e => setEditingTeamMember({...editingTeamMember, order: parseInt(e.target.value)})} 
                                  />
                                </div>
                                <Button type="submit" className="w-full bg-blue-600">Simpan Perubahan</Button>
                              </form>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete('team', member.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {team.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-10 text-slate-500">
                      Belum ada data anggota tim
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Pengaturan Sistem</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Informasi Header & Footer</CardTitle>
                  <CardDescription>Atur tampilan utama dan informasi kontak website</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleUpdateSettings} className="space-y-6">
                    <div className="space-y-4 pb-4 border-b">
                      <h3 className="font-medium">Hero / Header Utama</h3>
                      <div className="space-y-2">
                        <Label>Judul Hero (Hero Title)</Label>
                        <Input 
                          value={settingsForm.heroTitle}
                          onChange={e => setSettingsForm({...settingsForm, heroTitle: e.target.value})}
                          placeholder="Contoh: Membangun Masa Depan Bersama STIE Eka Prasetya"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Sub-judul Hero (Hero Subtitle)</Label>
                        <Textarea 
                          value={settingsForm.heroSubtitle}
                          onChange={e => setSettingsForm({...settingsForm, heroSubtitle: e.target.value})}
                          placeholder="Deskripsi singkat di bawah judul utama..."
                          className="h-20"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>URL Gambar Header (Hero Image URL)</Label>
                        <Input 
                          value={settingsForm.heroImageUrl}
                          onChange={e => setSettingsForm({...settingsForm, heroImageUrl: e.target.value})}
                          placeholder="https://..."
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-medium">Informasi Footer</h3>
                      <Label>Deskripsi Footer</Label>
                      <Textarea 
                        value={settingsForm.footerDescription}
                        onChange={e => setSettingsForm({...settingsForm, footerDescription: e.target.value})}
                        placeholder="Deskripsi singkat tentang kampus..."
                        className="h-32"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label>Alamat</Label>
                        <Input 
                          value={settingsForm.address}
                          onChange={e => setSettingsForm({...settingsForm, address: e.target.value})}
                          placeholder="Alamat lengkap kampus"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Nomor Telepon</Label>
                        <Input 
                          value={settingsForm.phone}
                          onChange={e => setSettingsForm({...settingsForm, phone: e.target.value})}
                          placeholder="(061) XXXX"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Email</Label>
                        <Input 
                          value={settingsForm.email}
                          onChange={e => setSettingsForm({...settingsForm, email: e.target.value})}
                          placeholder="info@ekaprasetya.ac.id"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Nomor WhatsApp (Gunakan format 62...)</Label>
                        <Input 
                          value={settingsForm.whatsappNumber}
                          onChange={e => setSettingsForm({...settingsForm, whatsappNumber: e.target.value})}
                          placeholder="628123456789"
                        />
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label>Pesan Otomatis WhatsApp</Label>
                        <Input 
                          value={settingsForm.whatsappMessage}
                          onChange={e => setSettingsForm({...settingsForm, whatsappMessage: e.target.value})}
                          placeholder="Halo, saya ingin bertanya tentang..."
                        />
                      </div>
                    </div>

                    <div className="space-y-4 pt-4 border-t">
                      <h3 className="font-medium">Media Sosial</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label>Facebook URL</Label>
                          <Input 
                            value={settingsForm.facebookUrl}
                            onChange={e => setSettingsForm({...settingsForm, facebookUrl: e.target.value})}
                            placeholder="https://facebook.com/..."
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Instagram URL</Label>
                          <Input 
                            value={settingsForm.instagramUrl}
                            onChange={e => setSettingsForm({...settingsForm, instagramUrl: e.target.value})}
                            placeholder="https://instagram.com/..."
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Youtube URL</Label>
                          <Input 
                            value={settingsForm.youtubeUrl}
                            onChange={e => setSettingsForm({...settingsForm, youtubeUrl: e.target.value})}
                            placeholder="https://youtube.com/..."
                          />
                        </div>
                      </div>
                    </div>

                    <Button type="submit" className="w-full bg-blue-600">Simpan Pengaturan</Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Status Sistem</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="text-sm text-slate-500">Terakhir Diperbarui</span>
                    <span className="text-sm font-medium">
                      {formatSafeDate(settings?.updatedAt, 'dd/MM/yyyy HH:mm')}
                    </span>
                  </div>
                  <div className="bg-amber-50 p-4 rounded-lg border border-amber-100">
                    <p className="text-xs text-amber-700">
                      Perubahan pada pengaturan ini akan langsung berdampak pada tampilan footer di seluruh halaman website.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0">
                  <div>
                    <CardTitle>Tautan Cepat</CardTitle>
                    <CardDescription>Kelola link di footer</CardDescription>
                  </div>
                  <Dialog>
                    <DialogTrigger nativeButton render={<Button size="sm" className="bg-blue-600"><Plus className="h-4 w-4 mr-1" /> Tambah</Button>} />
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Tambah Tautan Cepat</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleAddQuickLink} className="space-y-4">
                        <div className="space-y-2">
                          <Label>Judul Tautan</Label>
                          <Input 
                            required 
                            value={newQuickLink.title} 
                            onChange={e => setNewQuickLink({...newQuickLink, title: e.target.value})} 
                            placeholder="Contoh: Website Utama"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>URL</Label>
                          <Input 
                            required 
                            value={newQuickLink.url} 
                            onChange={e => setNewQuickLink({...newQuickLink, url: e.target.value})} 
                            placeholder="https://..."
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Urutan Tampil</Label>
                          <Input 
                            type="number" 
                            required 
                            value={newQuickLink.order} 
                            onChange={e => setNewQuickLink({...newQuickLink, order: parseInt(e.target.value)})} 
                          />
                        </div>
                        <Button type="submit" className="w-full bg-blue-600">Tambah Tautan</Button>
                      </form>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {quickLinks.length === 0 ? (
                      <p className="text-sm text-slate-500 text-center py-4 italic">Belum ada tautan</p>
                    ) : (
                      quickLinks.map((link) => (
                        <div key={link.id} className="flex items-center justify-between p-2 rounded-md border border-slate-100 bg-slate-50/50 group">
                          <div className="flex flex-col">
                            <span className="text-sm font-medium">{link.title}</span>
                            <span className="text-[10px] text-slate-400 truncate max-w-[150px]">{link.url}</span>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleDelete('quickLinks', link.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0">
                  <div>
                    <CardTitle>Logo Partner</CardTitle>
                    <CardDescription>Logo berjalan di halaman depan</CardDescription>
                  </div>
                  <Dialog>
                    <DialogTrigger nativeButton render={<Button size="sm" className="bg-blue-600"><Plus className="h-4 w-4 mr-1" /> Tambah</Button>} />
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Tambah Logo Partner</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleAddPartnerLogo} className="space-y-4">
                        <div className="space-y-2">
                          <Label>Nama Partner</Label>
                          <Input 
                            required 
                            value={newPartnerLogo.name} 
                            onChange={e => setNewPartnerLogo({...newPartnerLogo, name: e.target.value})} 
                            placeholder="Contoh: Bank Sumut"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>URL Logo (Image)</Label>
                          <Input 
                            required 
                            value={newPartnerLogo.imageUrl} 
                            onChange={e => setNewPartnerLogo({...newPartnerLogo, imageUrl: e.target.value})} 
                            placeholder="https://..."
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Urutan Tampil</Label>
                          <Input 
                            type="number" 
                            required 
                            value={newPartnerLogo.order} 
                            onChange={e => setNewPartnerLogo({...newPartnerLogo, order: parseInt(e.target.value)})} 
                          />
                        </div>
                        <Button type="submit" className="w-full bg-blue-600">Tambah Logo</Button>
                      </form>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    {partnerLogos.length === 0 ? (
                      <p className="text-sm text-slate-500 text-center py-4 italic col-span-2">Belum ada logo</p>
                    ) : (
                      partnerLogos.map((logo) => (
                        <div key={logo.id} className="flex items-center justify-between p-2 rounded-md border border-slate-100 bg-slate-50/50 group">
                          <div className="flex items-center gap-2 overflow-hidden">
                            <img src={logo.imageUrl} alt={logo.name} className="h-8 w-8 object-contain shrink-0" referrerPolicy="no-referrer" />
                            <span className="text-xs font-medium truncate">{logo.name}</span>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleDelete('partnerLogos', logo.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Password Tab */}
        <TabsContent value="password" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Pengaturan Keamanan</h2>
          </div>
          
          <div className="max-w-xl">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-blue-600" />
                  Mengatur Password Admin
                </CardTitle>
                <CardDescription>
                  Perbarui kata sandi untuk akun administrator portal kemahasiswaan STIE Eka Prasetya.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleChangePassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Password Lama</Label>
                    <Input 
                      id="current-password"
                      type="password"
                      required
                      placeholder="Masukkan password saat ini"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-password">Password Baru</Label>
                    <Input 
                      id="new-password"
                      type="password"
                      required
                      placeholder="Minimal 6 karakter"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Konfirmasi Password Baru</Label>
                    <Input 
                      id="confirm-password"
                      type="password"
                      required
                      placeholder="Ulangi password baru"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg cursor-pointer"
                    disabled={passwordLoading}
                  >
                    {passwordLoading ? 'Menyimpan...' : 'Perbarui Password'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Konfirmasi Hapus</DialogTitle>
            <DialogDescription>
              Apakah Anda yakin ingin menghapus data ini? Tindakan ini tidak dapat dibatalkan.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setDeleteConfirm(null)}>Batal</Button>
            <Button variant="destructive" onClick={confirmDelete}>Hapus</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
