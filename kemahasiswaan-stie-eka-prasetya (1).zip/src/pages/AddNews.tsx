import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { db, auth, storage } from '../lib/firebase';
import { collection, addDoc, getDocs, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Category } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Checkbox } from '../components/ui/checkbox';
import { Search } from 'lucide-react';
import ReactQuill from 'react-quill-new';
import 'react-quill-new/dist/quill.snow.css';
import { toast } from 'sonner';
import { ArrowLeft, Save, Image as ImageIcon, Newspaper } from 'lucide-react';
import { motion } from 'motion/react';

export default function AddNews() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    categoryId: '',
    imageUrl: '',
    isPrestasi: false,
    isKemahasiswaan: false,
    isEvent: false,
    metaTitle: '',
    metaDescription: '',
    keywords: ''
  });

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const catSnap = await getDocs(collection(db, 'categories'));
        setCategories(catSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category)));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'categories');
      }
    };
    fetchCategories();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.content || !formData.categoryId) {
      toast.error('Harap isi semua field yang wajib (Judul, Konten, Kategori)');
      return;
    }

    setLoading(true);
    try {
      await addDoc(collection(db, 'news'), {
        ...formData,
        authorId: auth.currentUser?.uid,
        createdAt: serverTimestamp(),
      });
      toast.success('Berita berhasil dipublikasikan');
      navigate('/admin');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'news');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Harap pilih file gambar (JPG, PNG, dll)');
      return;
    }

    // Validate size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Ukuran gambar terlalu besar (maksimal 2MB)');
      return;
    }

    setUploading(true);
    const toastId = toast.loading('Sedang mengunggah gambar...');

    try {
      console.log('Starting upload for file:', file.name);
      
      // Upload with timeout
      const uploadPromise = (async () => {
        const fileExtension = file.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${fileExtension}`;
        const storageRef = ref(storage, `news/${fileName}`);
        const snapshot = await uploadBytes(storageRef, file);
        return await getDownloadURL(snapshot.ref);
      })();

      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('timeout')), 30000)
      );

      const downloadURL = await Promise.race([uploadPromise, timeoutPromise]) as string;
      
      setFormData(prev => ({ ...prev, imageUrl: downloadURL }));
      toast.success('Gambar berhasil diunggah', { id: toastId });
    } catch (error: any) {
      console.error('Detailed upload error:', error);
      let errorMessage = 'Gagal mengunggah gambar';
      
      if (error.message === 'timeout') {
        errorMessage = 'Unggahan lambat atau terhenti. Silakan periksa koneksi internet atau coba lagi.';
      } else if (error.code === 'storage/unauthorized') {
        errorMessage = 'Izin ditolak. Anda tidak memiliki akses untuk mengunggah. Pastikan Firebase Storage sudah aktif di konsol.';
      } else if (error.code === 'storage/unknown') {
        errorMessage = 'Kesalahan server storage. Pastikan fitur Storage sudah diaktifkan.';
      }
      
      toast.error(errorMessage, { id: toastId });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto"
      >
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/admin')}
              className="rounded-full"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Tambah Berita Baru</h1>
              <p className="text-slate-500">Buat dan publikasikan berita kemahasiswaan terbaru</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => navigate('/admin')}>Batal</Button>
            <Button onClick={handleSubmit} disabled={loading} className="bg-blue-600 hover:bg-blue-700">
              <Save className="h-4 w-4 mr-2" />
              {loading ? 'Menyimpan...' : 'Publikasikan'}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>Konten Berita</CardTitle>
                <CardDescription>Tulis isi berita secara detail di sini</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Judul Berita</Label>
                  <Input 
                    id="title" 
                    placeholder="Masukkan judul berita yang menarik..." 
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    className="text-lg font-medium py-6"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Isi Berita</Label>
                  <div className="bg-white rounded-md border border-slate-200 overflow-hidden">
                    <ReactQuill 
                      theme="snow"
                      value={formData.content}
                      onChange={(content) => setFormData(prev => ({ ...prev, content }))}
                      className="h-96"
                      placeholder="Tuliskan isi berita Anda di sini..."
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Search className="h-5 w-5 text-blue-600" />
                  <CardTitle>Pengaturan SEO (Search Engine Optimization)</CardTitle>
                </div>
                <CardDescription>Optimalkan berita agar mudah ditemukan di mesin pencari seperti Google</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="metaTitle">Meta Title</Label>
                  <Input 
                    id="metaTitle" 
                    placeholder="Judul khusus untuk mesin pencari..." 
                    value={formData.metaTitle}
                    onChange={(e) => setFormData(prev => ({ ...prev, metaTitle: e.target.value }))}
                  />
                  <p className="text-xs text-slate-400">Judul yang muncul di hasil pencarian Google. Idealnya di bawah 60 karakter.</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="metaDescription">Meta Description</Label>
                  <Textarea 
                    id="metaDescription" 
                    placeholder="Ringkasan berita untuk deskripsi pencarian..." 
                    value={formData.metaDescription}
                    onChange={(e) => setFormData(prev => ({ ...prev, metaDescription: e.target.value }))}
                    className="h-24"
                  />
                  <p className="text-xs text-slate-400">Deskripsi singkat yang muncul di bawah judul pada hasil pencarian. Idealnya 150-160 karakter.</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="keywords">Keywords</Label>
                  <Input 
                    id="keywords" 
                    placeholder="Contoh: kuliahmudah, beasiswakampus, prestasi mahasiswa..." 
                    value={formData.keywords}
                    onChange={(e) => setFormData(prev => ({ ...prev, keywords: e.target.value }))}
                  />
                  <p className="text-xs text-slate-400">Kata kunci relevan dipisahkan dengan koma.</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Area */}
          <div className="space-y-8">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>Pengaturan Berita</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="category">Kategori</Label>
                  <Select 
                    value={formData.categoryId} 
                    onValueChange={(val) => setFormData(prev => ({ ...prev, categoryId: val }))}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Pilih kategori" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="imageUpload">Upload Gambar Sampul</Label>
                  <Input 
                    id="imageUpload" 
                    type="file" 
                    accept="image/*"
                    onChange={handleFileChange}
                    disabled={uploading}
                    className="cursor-pointer"
                  />
                  <div className="pt-2">
                    <Label htmlFor="imageUrl">Atau gunakan URL Gambar</Label>
                    <div className="flex gap-2">
                      <div className="relative flex-grow">
                        <ImageIcon className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                        <Input 
                          id="imageUrl" 
                          placeholder="https://..." 
                          className="pl-10"
                          value={formData.imageUrl}
                          onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                        />
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400">Direkomendasikan ukuran 1200x600px (Max 2MB)</p>
                </div>

                {formData.imageUrl && (
                  <div className="mt-4 rounded-lg overflow-hidden border border-slate-200">
                    <img 
                      src={formData.imageUrl} 
                      alt="Preview" 
                      className="w-full h-40 object-cover"
                      referrerPolicy="no-referrer"
                      onError={(e) => (e.currentTarget.src = 'https://picsum.photos/seed/error/400/200')}
                    />
                  </div>
                )}

                <div className="space-y-4 pt-4 border-t border-slate-100">
                  <Label>Label Tambahan</Label>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="isPrestasi" 
                      checked={formData.isPrestasi}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isPrestasi: !!checked }))}
                    />
                    <Label htmlFor="isPrestasi" className="text-sm font-normal cursor-pointer">Tandai sebagai Prestasi</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="isKemahasiswaan" 
                      checked={formData.isKemahasiswaan}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isKemahasiswaan: !!checked }))}
                    />
                    <Label htmlFor="isKemahasiswaan" className="text-sm font-normal cursor-pointer">Tandai sebagai Kemahasiswaan</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="isEvent" 
                      checked={formData.isEvent}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isEvent: !!checked }))}
                    />
                    <Label htmlFor="isEvent" className="text-sm font-normal cursor-pointer">Tandai sebagai Event</Label>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
              <div className="flex items-start gap-3">
                <Newspaper className="h-5 w-5 text-blue-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-blue-900">Tips Menulis</h4>
                  <p className="text-sm text-blue-700 mt-1">Gunakan judul yang singkat dan padat. Sertakan gambar yang relevan untuk menarik minat pembaca.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
