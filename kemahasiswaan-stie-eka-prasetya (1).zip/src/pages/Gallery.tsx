import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { GalleryItem } from '../types';
import { Card } from '../components/ui/card';
import { Image as ImageIcon, Maximize2 } from 'lucide-react';
import { motion } from 'motion/react';
import { Dialog, DialogContent, DialogTrigger } from '../components/ui/dialog';

export default function GalleryPage() {
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const snap = await getDocs(query(collection(db, 'gallery'), orderBy('createdAt', 'desc')));
        setGallery(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as GalleryItem)));
      } catch (error) {
        console.error('Error fetching gallery:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Galeri Kegiatan</h1>
        <p className="text-slate-500 max-w-2xl mx-auto">
          Momen-momen berharga dari berbagai kegiatan kemahasiswaan dan akademik di STIE Eka Prasetya.
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <div key={i} className="aspect-square bg-slate-200 animate-pulse rounded-xl"></div>
          ))}
        </div>
      ) : gallery.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {gallery.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Dialog>
                <DialogTrigger render={
                  <Card className="overflow-hidden group cursor-pointer relative aspect-square border-none shadow-sm">
                    <img 
                      src={item.imageUrl} 
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <div className="bg-white/20 backdrop-blur-md p-3 rounded-full">
                        <Maximize2 className="h-6 w-6 text-white" />
                      </div>
                    </div>
                  </Card>
                } />
                <DialogContent className="max-w-4xl p-0 overflow-hidden bg-transparent border-none shadow-none">
                  <div className="relative">
                    <img 
                      src={item.imageUrl} 
                      alt={item.title} 
                      className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent text-white rounded-b-lg">
                      <h3 className="text-xl font-bold">{item.title}</h3>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
          <ImageIcon className="h-16 w-16 text-slate-200 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-slate-900">Belum ada foto</h3>
          <p className="text-slate-500">Galeri akan segera diperbarui dengan foto-foto terbaru.</p>
        </div>
      )}
    </div>
  );
}
