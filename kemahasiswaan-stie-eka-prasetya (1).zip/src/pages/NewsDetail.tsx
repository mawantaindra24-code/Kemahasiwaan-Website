import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { doc, getDoc, collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { News, Category } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Calendar, ArrowLeft, Share2, Clock, User, Newspaper, ArrowRight } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { formatSafeDate } from '../lib/utils';
import { motion } from 'motion/react';

export default function NewsDetail() {
  const { id: newsId } = useParams();
  const navigate = useNavigate();
  const [news, setNews] = useState<News | null>(null);
  const [relatedNews, setRelatedNews] = useState<News[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const calculateReadTime = (text: string) => {
    const wordsPerMinute = 200;
    const noOfWords = text.replace(/<[^>]*>/g, '').split(/\s+/).length;
    const minutes = Math.ceil(noOfWords / wordsPerMinute);
    return minutes;
  };

  useEffect(() => {
    const fetchData = async () => {
      if (!newsId) return;
      try {
        // Fetch Categories
        const catSnap = await getDocs(collection(db, 'categories'));
        setCategories(catSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category)));

        // Fetch News
        const newsDoc = await getDoc(doc(db, 'news', newsId));
        if (newsDoc.exists()) {
          const currentNews = { id: newsDoc.id, ...newsDoc.data() } as News;
          setNews(currentNews);

          // Fetch Latest News as "Related" (excluding current)
          const latestSnap = await getDocs(collection(db, 'news'));
          const otherNews = latestSnap.docs
            .map(doc => ({ id: doc.id, ...doc.data() } as News))
            .filter(n => n.id !== newsId)
            .slice(0, 3);
          setRelatedNews(otherNews);
        } else {
          navigate('/news');
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `news/${newsId}`);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [newsId, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!news) return null;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    alert('Link berita berhasil disalin!');
  };

  const category = categories.find(c => c.id === news.categoryId);
  const readTime = calculateReadTime(news.content);

  return (
    <div className="min-h-screen bg-white">
      <Helmet>
        <title>{news.metaTitle || `${news.title} | STIE Eka Prasetya`}</title>
        <meta name="description" content={news.metaDescription || news.content.substring(0, 160).replace(/<[^>]*>/g, '')} />
        {news.keywords && <meta name="keywords" content={news.keywords} />}
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="article" />
        <meta property="og:title" content={news.metaTitle || news.title} />
        <meta property="og:description" content={news.metaDescription || news.content.substring(0, 160).replace(/<[^>]*>/g, '')} />
        {news.imageUrl && <meta property="og:image" content={news.imageUrl} />}
        <meta property="og:url" content={window.location.href} />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={news.metaTitle || news.title} />
        <meta name="twitter:description" content={news.metaDescription || news.content.substring(0, 160).replace(/<[^>]*>/g, '')} />
        {news.imageUrl && <meta name="twitter:image" content={news.imageUrl} />}
      </Helmet>
      {/* Progress Bar */}
      <motion.div 
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        className="fixed top-0 left-0 right-0 h-1 bg-blue-600 z-[60] origin-left"
      />

      {/* Content Section */}
      <article className="pb-24">
        {/* Modern Hero Header */}
        <section className="relative h-[60vh] min-h-[400px] flex items-end overflow-hidden bg-slate-900 mb-16">
          <div className="absolute inset-0 z-0">
            {news.imageUrl ? (
              <img 
                src={news.imageUrl} 
                alt={news.title} 
                className="w-full h-full object-cover opacity-60 scale-105"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full bg-slate-800 flex items-center justify-center">
                <Newspaper className="h-20 w-20 text-slate-700" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
          </div>
          
          <div className="max-w-5xl mx-auto px-6 relative z-10 w-full pb-16">
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <Badge className="bg-blue-600 hover:bg-blue-600 border-none px-4 py-1 uppercase tracking-widest text-[10px] font-black">
                {category?.name || 'Berita'}
              </Badge>
              {news.isPrestasi && <Badge variant="secondary" className="bg-white/10 text-white border-white/20 backdrop-blur-md">#Prestasi</Badge>}
            </div>
            
            <h1 className="text-4xl md:text-6xl font-black text-white leading-[1.1] tracking-tight mb-8">
              {news.title}
            </h1>

            <div className="flex flex-wrap items-center gap-y-4 gap-x-8 text-sm text-slate-300 font-medium">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center text-white border border-white/20">
                  <User className="h-5 w-5" />
                </div>
                <span className="font-bold text-white">Admin Kemahasiswaan</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-blue-400" />
                {formatSafeDate(news.createdAt)}
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-blue-400" />
                {readTime} Menit Baca
              </div>
            </div>
          </div>
        </section>

        <div className="max-w-4xl mx-auto px-6">
          <div className="flex flex-col gap-10">
            {/* Main Content Area */}
            <div className="w-full overflow-hidden break-words">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="prose prose-slate prose-lg md:prose-xl max-w-none font-serif
                  prose-headings:font-sans prose-headings:font-black prose-headings:tracking-tight prose-headings:text-slate-900
                  prose-p:text-slate-700 prose-p:leading-[1.9] prose-p:mb-10
                  prose-a:text-blue-600 prose-a:font-bold prose-a:no-underline hover:prose-a:underline
                  prose-blockquote:font-sans prose-blockquote:border-l-8 prose-blockquote:border-blue-600 prose-blockquote:bg-blue-50 prose-blockquote:py-8 prose-blockquote:px-12 prose-blockquote:rounded-r-3xl prose-blockquote:not-italic prose-blockquote:text-slate-800 prose-blockquote:text-xl md:prose-blockquote:text-2xl prose-blockquote:shadow-sm
                  prose-img:rounded-3xl prose-img:shadow-2xl prose-img:mx-auto prose-img:w-full
                  prose-strong:text-slate-900 prose-strong:font-black
                  prose-ul:list-disc prose-ol:list-decimal
                  prose-li:text-slate-700 prose-li:mb-2
                  prose-hr:border-slate-100"
                dangerouslySetInnerHTML={{ __html: news.content }}
              />

              {/* Post Footer */}
              <div className="mt-20 pt-12 border-t border-slate-100">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-8 bg-slate-50 p-8 rounded-[32px] border border-slate-100">
                  <div className="space-y-1">
                    <div className="text-xs font-black text-slate-400 uppercase tracking-widest">Bagikan Cerita Ini</div>
                    <div className="text-xl font-bold text-slate-900">Inspirasi Untuk Orang Lain</div>
                  </div>
                  <Button 
                    onClick={handleShare}
                    size="lg"
                    className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-6 font-bold gap-3 shadow-xl shadow-blue-600/20 transition-all hover:scale-105 active:scale-95"
                  >
                    <Share2 className="h-5 w-5" /> Copy Link Berita
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* More News Section */}
        {relatedNews.length > 0 && (
          <section className="max-w-7xl mx-auto px-6 mt-32">
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tight mb-2">Informasi Lainnya</h2>
                <div className="h-1.5 w-20 bg-blue-600 rounded-full"></div>
              </div>
              <Link to="/news">
                <Button variant="ghost" className="text-blue-600 font-bold group">
                  Semua Berita <ArrowRight className="h-4 w-4 ml-2 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {relatedNews.map((item) => (
                <Link key={item.id} to={`/news/${item.id}`} className="group">
                  <div className="flex flex-col h-full bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-sm transition-all duration-500 hover:shadow-2xl hover:-translate-y-2">
                    <div className="aspect-[16/10] overflow-hidden">
                      {item.imageUrl ? (
                        <img 
                          src={item.imageUrl} 
                          alt={item.title} 
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-full h-full bg-slate-50 flex items-center justify-center">
                          <Newspaper className="h-12 w-12 text-slate-200" />
                        </div>
                      )}
                    </div>
                    <div className="p-8 flex-grow flex flex-col">
                      <div className="flex items-center gap-3 mb-4">
                        <Badge variant="secondary" className="bg-blue-50 text-blue-600 border-none px-3 text-[10px] uppercase font-black tracking-widest">
                          {categories.find(c => c.id === item.categoryId)?.name || 'Berita'}
                        </Badge>
                        <span className="text-[10px] font-bold text-slate-400 capitalize">
                          {formatSafeDate(item.createdAt, 'dd MMM')}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold text-slate-900 leading-snug group-hover:text-blue-600 transition-colors line-clamp-2 mb-4 capitalize">
                        {item.title}
                      </h3>
                      <div className="mt-auto pt-4 border-t border-slate-50 flex items-center text-blue-600 text-xs font-bold">
                        Baca Selengkapnya <ArrowRight className="h-3 w-3 ml-1" />
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </article>

      {/* Floating Back Button */}
      <div className="fixed top-8 left-8 z-[100]">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(-1)}
          className="bg-white hover:bg-slate-50 text-slate-900 rounded-full shadow-xl border border-slate-200 h-12 w-12"
        >
          <ArrowLeft className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
}
