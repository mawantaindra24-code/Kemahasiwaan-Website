import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Download } from '../types';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Download as DownloadIcon, FileText, Search, ExternalLink } from 'lucide-react';
import { Input } from '../components/ui/input';
import { formatSafeDate } from '../lib/utils';

export default function DownloadsPage() {
  const [downloads, setDownloads] = useState<Download[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const snap = await getDocs(query(collection(db, 'downloads'), orderBy('createdAt', 'desc')));
        setDownloads(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Download)));
      } catch (error) {
        console.error('Error fetching downloads:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const filteredDownloads = downloads.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const categories = Array.from(new Set(downloads.map(d => d.category)));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Pusat Download</h1>
        <p className="text-slate-500 max-w-2xl">
          Unduh berbagai dokumen, formulir, dan panduan kemahasiswaan yang Anda butuhkan.
        </p>
      </div>

      <div className="mb-10 max-w-md">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Cari dokumen..." 
            className="pl-10"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-20 bg-slate-200 animate-pulse rounded-xl"></div>
          ))}
        </div>
      ) : filteredDownloads.length > 0 ? (
        <div className="space-y-12">
          {categories.map(cat => {
            const catDocs = filteredDownloads.filter(d => d.category === cat);
            if (catDocs.length === 0) return null;
            
            return (
              <div key={cat} className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-1 bg-blue-600 rounded-full"></div>
                  <h2 className="text-2xl font-bold text-slate-900">{cat}</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {catDocs.map((doc) => (
                    <Card key={doc.id} className="border-slate-200 hover:border-blue-400 hover:shadow-md transition-all group">
                      <CardContent className="p-4 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="p-3 bg-blue-50 rounded-xl text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                            <FileText className="h-6 w-6" />
                          </div>
                          <div>
                            <h3 className="font-bold text-slate-900 leading-tight">{doc.title}</h3>
                            <p className="text-xs text-slate-500 mt-1">
                              Diunggah pada {formatSafeDate(doc.createdAt, 'dd MMM yyyy')}
                            </p>
                          </div>
                        </div>
                        <Button size="sm" variant="outline" className="border-slate-200 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200" render={
                          <a href={doc.fileUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                            Unduh <ExternalLink className="h-3 w-3" />
                          </a>
                        } />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
          <DownloadIcon className="h-16 w-16 text-slate-200 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-slate-900">Tidak ada dokumen ditemukan</h3>
          <p className="text-slate-500">Coba gunakan kata kunci lain.</p>
        </div>
      )}
    </div>
  );
}
