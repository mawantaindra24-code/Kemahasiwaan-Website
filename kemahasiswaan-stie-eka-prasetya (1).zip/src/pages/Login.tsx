import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { auth, googleProvider, signInWithPopup } from '../lib/firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { toast } from 'sonner';
import { LogIn, ArrowLeft } from 'lucide-react';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    setLoading(true);
    try {
      // Allow raw email, or if it's a simple username, append a fallback domain
      const email = username.includes('@') ? username : `${username}@gmail.com`;
      await signInWithEmailAndPassword(auth, email, password);
      toast.success('Login berhasil!');
      navigate('/admin');
    } catch (error: any) {
      let friendlyMessage = 'Gagal login. Periksa email/username dan password.';
      if (error.code === 'auth/user-not-found') {
        friendlyMessage = 'Akun tidak ditemukan. Silakan registrasi di konsol Firebase.';
      } else if (error.code === 'auth/wrong-password') {
        friendlyMessage = 'Password yang Anda masukkan salah.';
      } else if (error.code === 'auth/invalid-email') {
        friendlyMessage = 'Format email tidak valid.';
      }
      toast.error(friendlyMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
      toast.success('Login berhasil dengan akun Google!');
      navigate('/admin');
    } catch (error: any) {
      toast.error('Gagal login via Google: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-md space-y-4">
        <Link to="/" className="flex items-center gap-2 text-slate-500 hover:text-blue-600 transition-colors mb-4 w-fit">
          <ArrowLeft className="h-4 w-4" /> Kembali ke Beranda
        </Link>
        <Card className="border-slate-200 shadow-xl">
          <CardHeader className="space-y-1 text-center bg-slate-900 text-white rounded-t-xl py-8">
            <div className="flex justify-center mb-4">
              <div className="bg-blue-600 p-3 rounded-2xl shadow-lg">
                <LogIn className="h-8 w-8" />
              </div>
            </div>
            <CardTitle className="text-2xl font-black">Admin STIE</CardTitle>
            <CardDescription className="text-slate-400">
              Silakan masuk untuk mengelola portal
            </CardDescription>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-slate-700">Email atau Username</Label>
                <Input 
                  id="username"
                  required 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin@email.com atau admin"
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                </div>
                <Input 
                  id="password"
                  type="password" 
                  required 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 py-6 text-lg font-bold shadow-lg" disabled={loading}>
                {loading ? 'Masuk...' : 'Masuk sekarang'}
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-slate-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-slate-500">Atau masuk dengan</span>
              </div>
            </div>

            <Button 
              type="button" 
              onClick={handleGoogleLogin} 
              variant="outline"
              className="w-full border-slate-200 text-slate-705 hover:bg-slate-50 py-6 font-semibold"
              disabled={loading}
            >
              <svg className="mr-2 h-5 w-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              Google Account
            </Button>
          </CardContent>
        </Card>
        <p className="text-center text-xs text-slate-400">
          &copy; 2026 STIE Eka Prasetya. All rights reserved.
        </p>
      </div>
    </div>
  );
}
