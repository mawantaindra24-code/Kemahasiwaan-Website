import React, { useEffect, useState } from 'react';
import { News, Event, Category, Announcement, SystemSettings, JobVacancy, GalleryItem, TeamMember } from '../types';
import { db } from '../lib/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import NewsCard from '../components/NewsCard';
import LogoMarquee from '../components/LogoMarquee';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Calendar, MapPin, ArrowRight, Newspaper, Image as ImageIcon, Download, ChevronRight, Bell, AlertTriangle, Briefcase, Building2, ExternalLink, Info } from 'lucide-react';
import { cn, formatSafeDate } from '../lib/utils';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '../components/ui/dialog';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';
import './home.css'; // I might need to create this for swiper dots or just use tailwind if possible

export default function Home() {
  const [latestNews, setLatestNews] = useState<News[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [jobs, setJobs] = useState<JobVacancy[]>([]);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [newsByCategory, setNewsByCategory] = useState<Record<string, News[]>>({});
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch Categories
        const catSnap = await getDocs(collection(db, 'categories'));
        const catList = catSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Category[];
        setCategories(catList);

        // Fetch Latest News
        const newsSnap = await getDocs(query(collection(db, 'news'), orderBy('createdAt', 'desc')));
        const newsList = newsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as News[];
        setLatestNews(newsList);

        // Fetch Events
        const eventsSnap = await getDocs(query(collection(db, 'events'), orderBy('date', 'asc')));
        const eventsList = eventsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Event[];
        setEvents(eventsList);

        // Fetch Announcements
        const annSnap = await getDocs(query(collection(db, 'announcements'), orderBy('createdAt', 'desc')));
        const annList = annSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Announcement[];
        setAnnouncements(annList);

        // Fetch Gallery
        const gallerySnap = await getDocs(query(collection(db, 'gallery'), orderBy('createdAt', 'desc')));
        const galleryList = gallerySnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as GalleryItem[];
        setGallery(galleryList);

        // Fetch News by Category (for widgets)
        const newsByCat: Record<string, News[]> = {};
        for (const cat of catList.slice(0, 3)) {
          // Efficient client-side filtering to limit Firestore reads
          newsByCat[cat.id] = newsList.filter(news => news.categoryId === cat.id);
        }
        setNewsByCategory(newsByCat);

        // Fetch Settings
        const settingsSnap = await getDocs(collection(db, 'settings'));
        if (!settingsSnap.empty) {
          const docFirst = settingsSnap.docs[0];
          setSettings({ id: docFirst.id, ...docFirst.data() } as SystemSettings);
        }

        // Fetch Jobs
        const jobsSnap = await getDocs(query(collection(db, 'jobs'), orderBy('createdAt', 'desc')));
        const jobsList = jobsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as JobVacancy[];
        setJobs(jobsList);

        // Fetch Team
        const teamSnap = await getDocs(query(collection(db, 'team'), orderBy('order', 'asc')));
        const teamList = teamSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as TeamMember[];
        setTeam(teamList);

      } catch (error) {
        console.error('Error fetching home data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative h-[500px] flex items-center overflow-hidden bg-slate-900">
        <div className="absolute inset-0 z-0">
          <img 
            src={settings?.heroImageUrl || "https://picsum.photos/seed/campus/1920/1080"} 
            alt="Campus" 
            className="w-full h-full object-cover opacity-40"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/80 to-transparent"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl lg:max-w-5xl"
          >
            <Badge className="mb-4 bg-blue-600 hover:bg-blue-600 border-none px-3 py-1">Portal Kemahasiswaan</Badge>
            <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-6">
              {settings?.heroTitle || "Membangun Masa Depan Bersama STIE Eka Prasetya"}
            </h1>
            <p className="text-lg text-slate-300 mb-8">
              {settings?.heroSubtitle || "Dapatkan informasi terbaru seputar kegiatan kampus, pengumuman penting, dan berbagai layanan kemahasiswaan dalam satu platform."}
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 h-12 px-8" render={
                <Link to="/news">Lihat Berita</Link>
              } />
              <Button variant="outline" size="lg" className="text-white border-white/30 hover:bg-white/10 h-12 px-8" render={
                <Link to="/gallery">Galeri Foto</Link>
              } />
            </div>
          </motion.div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content: Latest News */}
          <div className="lg:col-span-2 space-y-12">
            <div>
              <div className="flex justify-between items-end mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900">Berita Terbaru</h2>
                  <p className="text-slate-500">Informasi terkini seputar aktivitas kampus</p>
                </div>
                <Button variant="ghost" className="text-blue-600 hover:text-blue-700 font-semibold" render={
                  <Link to="/news" className="flex items-center gap-2">
                    Semua Berita <ArrowRight className="h-4 w-4" />
                  </Link>
                } />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {latestNews.length > 0 ? latestNews.map((news) => (
                  <motion.div 
                    key={news.id}
                    whileHover={{ y: -5 }}
                    className="group"
                  >
                    <NewsCard item={news} categories={categories} />
                  </motion.div>
                )) : (
                  <div className="col-span-2 text-center py-12 bg-slate-100 rounded-xl border-2 border-dashed border-slate-200">
                    <Newspaper className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">Belum ada berita yang dipublikasikan.</p>
                  </div>
                )}
              </div>
            </div>

            {/* News by Category Widgets */}
            <div className="space-y-12">
              {categories.slice(0, 2).map((cat) => (
                <div key={cat.id}>
                  <div className="flex items-center gap-2 mb-6">
                    <div className="h-8 w-1 bg-blue-600 rounded-full"></div>
                    <h3 className="text-2xl font-bold text-slate-900">{cat.name}</h3>
                  </div>
                  <div className="space-y-4">
                    {newsByCategory[cat.id]?.length > 0 ? newsByCategory[cat.id].map((news) => (
                      <Link key={news.id} to={`/news/${news.id}`} className="flex gap-4 p-3 rounded-lg hover:bg-white hover:shadow-sm transition-all group">
                        <div className="h-20 w-20 shrink-0 rounded-md overflow-hidden bg-slate-200">
                          <img 
                            src={news.imageUrl || `https://picsum.photos/seed/${news.id}/200/200`} 
                            alt={news.title}
                            className="h-full w-full object-cover group-hover:scale-110 transition-transform"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="flex flex-col justify-center">
                          <h4 className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2">
                            {news.title}
                          </h4>
                          <span className="text-xs text-slate-500 mt-1">
                            {formatSafeDate(news.createdAt, 'dd MMM yyyy')}
                          </span>
                        </div>
                      </Link>
                    )) : (
                      <p className="text-slate-400 text-sm italic">Belum ada berita di kategori ini.</p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Lowongan Pekerjaan Widget */}
            <div className="mt-12 bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
                <div className="flex items-center gap-3">
                  <div className="bg-purple-100 p-3 rounded-xl">
                    <Briefcase className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Pusat Karir & Pelatihan</h2>
                    <p className="text-slate-500 text-sm">Peluang kerja dan magang terbaru untuk Mahasiswa & Alumni</p>
                  </div>
                </div>
                <Button variant="ghost" className="text-purple-600 hover:text-purple-700 hover:bg-purple-50 group" render={<Link to="/downloads">Lihat Semua Info <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" /></Link>} />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {jobs.map((job) => (
                  <div key={job.id} className="flex flex-col h-full bg-slate-50 rounded-xl border border-slate-100 p-5 hover:border-purple-200 hover:bg-white hover:shadow-md transition-all group">
                    <div className="flex justify-between items-start mb-4">
                      <div className="bg-white p-2 rounded-lg border border-slate-100 shadow-sm overflow-hidden w-12 h-12 flex items-center justify-center">
                        {job.imageUrl ? (
                          <img 
                            src={job.imageUrl} 
                            alt={job.company} 
                            className="w-full h-full object-contain"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              e.currentTarget.parentElement?.classList.add('bg-slate-50');
                            }}
                          />
                        ) : (
                          <Building2 className="h-6 w-6 text-slate-400 group-hover:text-purple-500 transition-colors" />
                        )}
                      </div>
                      <Badge variant="secondary" className="bg-white text-purple-600 border-purple-100 text-[10px] px-2 py-0">
                        {job.type}
                      </Badge>
                    </div>
                    
                    <h3 className="font-bold text-slate-900 line-clamp-1 mb-1 group-hover:text-purple-700 transition-colors">{job.title}</h3>
                    <p className="text-sm font-semibold text-slate-600 mb-3">{job.company}</p>
                    
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-4">
                      <MapPin className="h-3.5 w-3.5" />
                      <span>{job.location}</span>
                    </div>

                    {job.description && (
                      <div 
                        className="text-xs text-slate-500 line-clamp-3 mb-6 prose-sm prose-slate"
                        dangerouslySetInnerHTML={{ __html: job.description }}
                      />
                    )}

                    <div className="mt-auto">
                      {job.link ? (
                        <a 
                          href={job.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-center gap-2 w-full text-xs font-bold text-white bg-slate-900 hover:bg-purple-600 py-2.5 rounded-lg transition-all"
                        >
                          Lamar Sekarang <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : (
                        <div className="w-full text-center text-[10px] text-slate-400 py-2 border border-dashed border-slate-200 rounded-lg">
                          Hubungi Prodi
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {jobs.length === 0 && (
                  <div className="col-span-full py-12 text-center bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
                    <Briefcase className="h-10 w-10 text-slate-300 mx-auto mb-3" />
                    <p className="text-slate-500">Belum ada lowongan pekerjaan saat ini</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar: Events & Quick Links */}
          <div className="space-y-10">
            {/* Announcements Widget */}
            {announcements.length > 0 && (
              <Card className="border-blue-200 shadow-md overflow-hidden bg-blue-50/30">
                <CardHeader className="bg-blue-600 text-white p-4">
                  <div className="flex items-center gap-2">
                    <Bell className="h-5 w-5" />
                    <CardTitle className="text-lg">Pengumuman</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y divide-blue-100">
                    {announcements.map((ann) => (
                      <Dialog key={ann.id}>
                        <DialogTrigger 
                          render={
                            <div 
                              className={`p-4 transition-colors cursor-pointer hover:bg-blue-100/50 group ${ann.isUrgent ? 'bg-amber-50/50 hover:bg-amber-100/50' : ''}`}
                              onClick={() => setSelectedAnnouncement(ann)}
                            />
                          }
                        >
                          <div className="flex gap-3">
                            {ann.isUrgent ? (
                              <motion.div
                                animate={{ opacity: [1, 0.4, 1] }}
                                transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                                className="shrink-0 mt-0.5"
                              >
                                <AlertTriangle className="h-5 w-5 text-amber-600" />
                              </motion.div>
                            ) : (
                              <Bell className="h-5 w-5 text-blue-400 shrink-0 mt-0.5 group-hover:text-blue-600 transition-colors" />
                            )}
                            <div className="space-y-1 flex-grow">
                              <div className="flex justify-between items-start">
                                <h4 className={`font-bold leading-tight group-hover:text-blue-700 transition-colors ${ann.isUrgent ? 'text-amber-900' : 'text-slate-900'}`}>
                                  {ann.title}
                                </h4>
                                <Info className="h-3.5 w-3.5 text-slate-300 group-hover:text-blue-500 shrink-0" />
                              </div>
                              <p className="text-sm text-slate-600 line-clamp-2">{ann.content}</p>
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1">
                                <span className="text-[10px] text-slate-400 uppercase font-bold">
                                  {formatSafeDate(ann.createdAt)}
                                </span>
                                {ann.deadline && (
                                  <span className="text-[10px] text-red-500 font-black uppercase flex items-center gap-1">
                                    <Calendar className="h-3 w-3" />
                                    Deadline: {formatSafeDate(ann.deadline)}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </DialogTrigger>
                        <DialogContent className="max-w-lg">
                          <DialogHeader>
                            <div className="flex items-center gap-2 mb-2">
                              {ann.isUrgent ? (
                                <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">
                                  <motion.div
                                    animate={{ opacity: [1, 0.4, 1] }}
                                    transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                                    className="flex items-center"
                                  >
                                    <AlertTriangle className="h-3 w-3 mr-1" />
                                  </motion.div>
                                  Penting
                                </Badge>
                              ) : (
                                <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200">
                                  <Bell className="h-3 w-3 mr-1" /> Pengumuman
                                </Badge>
                              )}
                            </div>
                            <DialogTitle className="text-2xl font-black text-slate-900 leading-tight">
                              {ann.title}
                            </DialogTitle>
                            <DialogDescription className="text-xs font-bold text-slate-400 uppercase tracking-widest pt-2">
                              Diterbitkan pada {formatSafeDate(ann.createdAt, 'dd MMMM yyyy')}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="pt-6 space-y-4">
                            {ann.deadline && (
                              <div className="bg-red-50 border border-red-100 p-4 rounded-xl flex items-center gap-3">
                                <div className="bg-red-100 p-2 rounded-lg text-red-600">
                                  <Calendar className="h-5 w-5" />
                                </div>
                                <div>
                                  <div className="text-[10px] font-bold text-red-400 uppercase tracking-widest">Batas Waktu / Deadline</div>
                                  <div className="text-sm font-black text-red-700">
                                    {formatSafeDate(ann.deadline, 'eeee, dd MMMM yyyy')}
                                  </div>
                                </div>
                              </div>
                            )}
                            <div className={`p-6 rounded-2xl border ${ann.isUrgent ? 'bg-amber-50/50 border-amber-100' : 'bg-slate-50 border-slate-100'}`}>
                              <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                                {ann.content}
                              </p>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Event Widget */}
            <Card className="border-slate-200 shadow-sm overflow-hidden">
              <CardHeader className="bg-slate-900 text-white p-6">
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-blue-400" />
                  <CardTitle className="text-lg">Agenda Kampus</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-slate-100">
                  {events.length > 0 ? events.map((event) => (
                    <Dialog key={event.id}>
                      <DialogTrigger 
                        render={
                          <div 
                            className="p-6 hover:bg-slate-50 transition-colors cursor-pointer group"
                            onClick={() => setSelectedEvent(event)}
                          />
                        }
                      >
                        <div className="flex gap-4">
                            <div className="flex flex-col items-center justify-center h-14 w-14 rounded-xl bg-blue-50 text-blue-600 shrink-0 border border-blue-100 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                              <span className="text-lg font-bold leading-none">{formatSafeDate(event.date, 'dd')}</span>
                              <span className="text-[10px] uppercase font-bold tracking-wider">{formatSafeDate(event.date, 'MMM')}</span>
                            </div>
                            <div className="space-y-1 flex-grow">
                              <div className="flex justify-between items-start">
                                <h4 className="font-bold text-slate-900 leading-tight group-hover:text-blue-600 transition-colors">{event.title}</h4>
                                <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-300 group-hover:text-blue-500">
                                  <Info className="h-4 w-4" />
                                </Button>
                              </div>
                              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                                <MapPin className="h-3 w-3" />
                                {event.location}
                              </div>
                            </div>
                          </div>
                      </DialogTrigger>
                      <DialogContent className="max-w-lg">
                        <DialogHeader>
                          <div className="flex items-center gap-3 mb-2">
                            <div className="bg-blue-100 text-blue-600 p-2 rounded-lg">
                              <Calendar className="h-5 w-5" />
                            </div>
                            <Badge variant="outline" className="text-blue-600 border-blue-200">Agenda Kampus</Badge>
                          </div>
                          <DialogTitle className="text-2xl font-black text-slate-900">{event.title}</DialogTitle>
                          <DialogDescription className="text-slate-500 pt-2">
                            Detail informasi agenda kegiatan yang akan datang.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-6 pt-6">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                              <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                                <Calendar className="h-3 w-3" /> Tanggal
                              </div>
                              <div className="text-sm font-bold text-slate-900 uppercase">
                                {formatSafeDate(event.date, 'dd MMMM yyyy')}
                              </div>
                            </div>
                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                              <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                                <MapPin className="h-3 w-3" /> Lokasi
                              </div>
                              <div className="text-sm font-bold text-slate-900">
                                {event.location}
                              </div>
                            </div>
                          </div>
                          <div className="bg-blue-50/50 p-6 rounded-2xl border border-blue-100/50">
                            <h5 className="text-sm font-black text-blue-600 uppercase tracking-widest mb-3">Deskripsi Kegiatan</h5>
                            <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                              {event.description || 'Tidak ada deskripsi tambahan untuk agenda ini.'}
                            </p>
                          </div>

                          {event.whatsapp && (
                            <div className="pt-2">
                              <a 
                                href={`https://wa.me/${event.whatsapp.replace(/[^0-9]/g, '')}`} 
                                target="_blank" 
                                rel="noreferrer"
                                className="inline-flex items-center justify-center w-full gap-2 bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-xl transition-all shadow-lg shadow-green-200"
                              >
                                <img src="https://img.icons8.com/color/48/whatsapp--v1.png" alt="WA" className="h-5 w-5" />
                                Hubungi via WhatsApp
                              </a>
                            </div>
                          )}
                        </div>
                      </DialogContent>
                    </Dialog>
                  )) : (
                    <div className="p-8 text-center text-slate-400 text-sm">
                      Tidak ada agenda mendatang.
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="bg-slate-50 p-4 justify-center border-t border-slate-100">
                <Button variant="ghost" size="sm" className="text-blue-600 font-bold">
                  Lihat Semua Agenda
                </Button>
              </CardFooter>
            </Card>

            {/* Quick Links Widget */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-900 px-2">Layanan Cepat</h3>
              <div className="grid grid-cols-1 gap-3">
                <Link to="/downloads" className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-50 rounded-lg text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <Download className="h-5 w-5" />
                    </div>
                    <span className="font-semibold text-slate-700">Pusat Download</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400" />
                </Link>
                <Link to="/gallery" className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-50 rounded-lg text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                      <ImageIcon className="h-5 w-5" />
                    </div>
                    <span className="font-semibold text-slate-700">Galeri Kegiatan</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-400" />
                </Link>
              </div>
            </div>

            {/* Gallery Slider Widget */}
            {gallery.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-slate-900 px-2">Momen Kampus</h3>
                <Card className="overflow-hidden border-slate-200 shadow-sm">
                  <Swiper
                    modules={[Autoplay, Pagination]}
                    spaceBetween={0}
                    slidesPerView={1}
                    autoplay={{ delay: 3000, disableOnInteraction: false }}
                    pagination={{ clickable: true }}
                    className="w-full h-56"
                  >
                    {gallery.map((item) => (
                      <SwiperSlide key={item.id}>
                        <div className="relative w-full h-full group cursor-pointer">
                          <img 
                            src={item.imageUrl} 
                            alt={item.title} 
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4">
                            <p className="text-white text-xs font-semibold line-clamp-2">{item.title}</p>
                          </div>
                        </div>
                      </SwiperSlide>
                    ))}
                  </Swiper>
                  <CardFooter className="bg-slate-50 p-3 justify-center border-t border-slate-100">
                    <Link to="/gallery" className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1">
                      Lihat Semua Galeri <ArrowRight className="h-3 w-3" />
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            )}

            {/* Team Members Widget */}
            {team.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-slate-900 px-2">Tim Kemahasiswaan</h3>
                <Card className="border-slate-200 shadow-sm overflow-hidden">
                  <div className="divide-y divide-slate-100">
                    {team.map((member) => (
                      <a 
                        key={member.id} 
                        href={member.whatsapp ? `https://wa.me/${member.whatsapp.replace(/\D/g, '')}` : '#'}
                        target={member.whatsapp ? "_blank" : undefined}
                        rel="noopener noreferrer"
                        className={`p-4 flex items-center justify-between hover:bg-blue-50 transition-all group ${member.whatsapp ? 'cursor-pointer' : 'cursor-default'}`}
                      >
                        <div className="flex items-center gap-4 overflow-hidden">
                          <div className="h-12 w-12 rounded-full overflow-hidden border-2 border-white shadow-sm shrink-0 bg-slate-100">
                            {member.imageUrl ? (
                              <img src={member.imageUrl} alt={member.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <div className="h-full w-full flex items-center justify-center bg-blue-100 text-blue-600 font-bold text-lg">
                                {member.name?.[0] || 'T'}
                              </div>
                            )}
                          </div>
                          <div className="overflow-hidden">
                            <h4 className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate">{member.name}</h4>
                            <p className="text-xs text-slate-500 font-medium truncate">{member.position}</p>
                          </div>
                        </div>
                        {member.whatsapp && (
                          <div className="text-green-500 opacity-0 group-hover:opacity-100 transition-all transform translate-x-2 group-hover:translate-x-0">
                            <ExternalLink className="h-4 w-4" />
                          </div>
                        )}
                      </a>
                    ))}
                  </div>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <LogoMarquee />
    </div>
  );
}
