// Updated for MySQL compatibility
export type DateField = Date | string | any;

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  createdAt: DateField;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface News {
  id: string;
  title: string;
  content: string;
  categoryId: string;
  imageUrl: string;
  authorId: string;
  createdAt: DateField;
  isPrestasi?: boolean;
  isKemahasiswaan?: boolean;
  isEvent?: boolean;
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  imageUrl: string;
  createdAt: DateField;
}

export interface Event {
  id: string;
  title: string;
  date: DateField;
  location: string;
  description: string;
  whatsapp?: string;
  createdAt: DateField;
}

export interface Download {
  id: string;
  title: string;
  fileUrl: string;
  category: string;
  createdAt: DateField;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  isActive: boolean;
  isUrgent: boolean;
  deadline?: DateField;
  createdAt: DateField;
}

export interface SystemSettings {
  id: string;
  heroTitle: string;
  heroSubtitle: string;
  heroImageUrl: string;
  footerDescription: string;
  address: string;
  phone: string;
  email: string;
  whatsappNumber: string;
  whatsappMessage: string;
  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  updatedAt: DateField;
}

export interface QuickLink {
  id: string;
  title: string;
  url: string;
  order: number;
  createdAt: DateField;
}

export interface PartnerLogo {
  id: string;
  name: string;
  imageUrl: string;
  order: number;
  createdAt: DateField;
}

export interface JobVacancy {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Internship';
  description?: string;
  imageUrl?: string;
  link?: string;
  createdAt: DateField;
}

export interface TeamMember {
  id: string;
  name: string;
  position: string;
  imageUrl?: string;
  whatsapp?: string;
  order: number;
  createdAt: DateField;
}
