import React, { createContext, useContext, useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { User } from './types';
import { AuthContext } from './context/AuthContext';
import { Toaster } from './components/ui/sonner';
import { auth, onAuthStateChanged, signOut } from './lib/firebase';

// Pages
import Home from './pages/Home';
import NewsPage from './pages/News';
import NewsDetail from './pages/NewsDetail';
import GalleryPage from './pages/Gallery';
import DownloadsPage from './pages/Downloads';
import AdminDashboard from './pages/AdminDashboard';
import AddNews from './pages/AddNews';
import EditNews from './pages/EditNews';
import AddJob from './pages/AddJob';
import EditJob from './pages/EditJob';
import Login from './pages/Login';

// Components
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import WhatsAppWidget from './components/WhatsAppWidget';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        setUser({
          id: firebaseUser.uid,
          name: firebaseUser.displayName || 'Administrator',
          email: firebaseUser.email || '',
          role: 'admin',
          createdAt: new Date().toISOString()
        });
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = (userData: User, token: string) => {
    setUser(userData);
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error("Error signing out:", e);
    }
    setUser(null);
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider value={{ user, loading, isAdmin, login, logout }}>
      <Router>
        <div className="min-h-screen flex flex-col bg-slate-50">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/news" element={<NewsPage />} />
              <Route path="/news/:id" element={<NewsDetail />} />
              <Route path="/gallery" element={<GalleryPage />} />
              <Route path="/downloads" element={<DownloadsPage />} />
              <Route path="/login" element={<Login />} />
              
              {/* Protected Admin Routes */}
              <Route 
                path="/admin" 
                element={
                  loading ? (
                    <div className="flex items-center justify-center h-screen">Loading...</div>
                  ) : isAdmin ? (
                    <AdminDashboard />
                  ) : (
                    <Navigate to="/login" />
                  )
                } 
              />
              <Route 
                path="/admin/news/add" 
                element={
                  loading ? (
                    <div className="flex items-center justify-center h-screen">Loading...</div>
                  ) : isAdmin ? (
                    <AddNews />
                  ) : (
                    <Navigate to="/login" />
                  )
                } 
              />
              <Route 
                path="/admin/news/edit/:id" 
                element={
                  loading ? (
                    <div className="flex items-center justify-center h-screen">Loading...</div>
                  ) : isAdmin ? (
                    <EditNews />
                  ) : (
                    <Navigate to="/login" />
                  )
                } 
              />
              <Route 
                path="/admin/jobs/add" 
                element={
                  loading ? (
                    <div className="flex items-center justify-center h-screen">Loading...</div>
                  ) : isAdmin ? (
                    <AddJob />
                  ) : (
                    <Navigate to="/login" />
                  )
                } 
              />
              <Route 
                path="/admin/jobs/edit/:id" 
                element={
                  loading ? (
                    <div className="flex items-center justify-center h-screen">Loading...</div>
                  ) : isAdmin ? (
                    <EditJob />
                  ) : (
                    <Navigate to="/login" />
                  )
                } 
              />
            </Routes>
          </main>
          <Footer />
          <WhatsAppWidget />
          <Toaster position="top-right" />
        </div>
      </Router>
    </AuthContext.Provider>
  );
}
