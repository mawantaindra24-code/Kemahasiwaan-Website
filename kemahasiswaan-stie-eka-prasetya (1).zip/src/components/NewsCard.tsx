import React from 'react';
import { Link } from 'react-router-dom';
import { News, Category } from '../types';
import { Card, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar } from 'lucide-react';
import { formatSafeDate } from '../lib/utils';
import { motion } from 'motion/react';

interface NewsCardProps {
  item: News;
  categories: Category[];
}

export default function NewsCard({ item, categories }: NewsCardProps) {
  const category = categories.find(c => c.id === item.categoryId);

  return (
    <Link to={`/news/${item.id}`}>
      <Card className="overflow-hidden border-slate-200 h-full flex flex-col shadow-sm hover:shadow-md transition-all group cursor-pointer">
        <div className="relative h-48 overflow-hidden">
          <img 
            src={item.imageUrl || `https://picsum.photos/seed/${item.id}/600/400`} 
            alt={item.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            referrerPolicy="no-referrer"
          />
          <div className="absolute top-4 left-4 flex flex-wrap gap-2">
            <Badge className="bg-white/90 text-blue-600 hover:bg-white border-none backdrop-blur-sm">
              {category?.name || 'Berita'}
            </Badge>
            {item.isPrestasi && <Badge className="bg-amber-500 text-white border-none">Prestasi</Badge>}
          </div>
        </div>
        <CardHeader className="p-5 flex-grow">
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
            <Calendar className="h-3 w-3" />
            {formatSafeDate(item.createdAt)}
          </div>
          <CardTitle className="text-xl font-bold leading-snug group-hover:text-blue-600 transition-colors">
            {item.title}
          </CardTitle>
        </CardHeader>
        <CardFooter className="p-5 pt-0">
          <p className="text-slate-600 text-sm line-clamp-3 mb-4">
            {item.content.replace(/<[^>]*>/g, '').slice(0, 150)}...
          </p>
          <span className="text-blue-600 text-xs font-bold">Baca Selengkapnya →</span>
        </CardFooter>
      </Card>
    </Link>
  );
}
