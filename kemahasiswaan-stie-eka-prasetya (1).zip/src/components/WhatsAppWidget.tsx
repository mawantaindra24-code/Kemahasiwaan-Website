import React, { useEffect, useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { SystemSettings } from '../types';
import { motion, AnimatePresence } from 'motion/react';

export default function WhatsAppWidget() {
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const snap = await getDocs(collection(db, 'settings'));
        if (!snap.empty) {
          setSettings({ id: snap.docs[0].id, ...snap.docs[0].data() } as SystemSettings);
        }
      } catch (error) {
        console.error('Error fetching settings for WhatsApp:', error);
      }
    };
    fetchSettings();
  }, []);

  if (!settings?.whatsappNumber) return null;

  const whatsappUrl = `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent(settings.whatsappMessage || 'Halo, saya ingin bertanya tentang kemahasiswaan.')}`;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-4">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="bg-white rounded-2xl shadow-2xl border border-slate-100 w-72 overflow-hidden"
          >
            <div className="bg-emerald-600 p-4 text-white">
              <div className="flex justify-between items-center mb-1">
                <h3 className="font-bold">Layanan Mahasiswa</h3>
                <button onClick={() => setIsOpen(false)} className="hover:bg-emerald-700 rounded-full p-1 transition-colors">
                  <X className="h-4 w-4" />
                </button>
              </div>
              <p className="text-xs text-emerald-100">Hubungi kami via WhatsApp</p>
            </div>
            <div className="p-4 bg-slate-50">
              <div className="bg-white p-3 rounded-lg shadow-sm border border-slate-100 text-sm text-slate-700 relative mb-4">
                Halo! Ada yang bisa kami bantu seputar layanan kemahasiswaan?
                <div className="absolute -left-2 top-3 w-0 h-0 border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent border-r-[8px] border-r-white"></div>
              </div>
              <a 
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-lg transition-colors shadow-md"
              >
                <MessageCircle className="h-5 w-5" />
                Mulai Chat
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="bg-emerald-600 hover:bg-emerald-700 text-white p-4 rounded-full shadow-2xl flex items-center justify-center transition-colors relative group"
      >
        <MessageCircle className="h-7 w-7" />
        <span className="absolute right-full mr-3 bg-slate-900 text-white text-xs py-1.5 px-3 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none shadow-xl">
          Butuh bantuan? Chat kami!
        </span>
      </motion.button>
    </div>
  );
}
