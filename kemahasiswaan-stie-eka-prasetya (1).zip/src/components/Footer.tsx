import React, { useEffect, useState } from 'react';
import { GraduationCap, Mail, Phone, MapPin, Facebook, Instagram, Youtube, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db } from '../lib/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { SystemSettings, QuickLink } from '../types';

export default function Footer() {
  const { user, logout } = useAuth();
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [quickLinks, setQuickLinks] = useState<QuickLink[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch settings
        const settingsSnap = await getDocs(collection(db, 'settings'));
        if (!settingsSnap.empty) {
          setSettings({ id: settingsSnap.docs[0].id, ...settingsSnap.docs[0].data() } as SystemSettings);
        }

        // Fetch quick links
        const linksSnap = await getDocs(query(collection(db, 'quickLinks'), orderBy('order', 'asc')));
        setQuickLinks(linksSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as QuickLink)));
      } catch (error) {
        console.error('Error fetching footer data:', error);
      }
    };
    fetchData();
  }, []);

  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-blue-600 p-1.5 rounded-lg">
                <GraduationCap className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-white">STIE Eka Prasetya</span>
            </div>
            <p className="text-slate-400 max-w-md mb-6">
              {settings?.footerDescription || "Sekolah Tinggi Ilmu Ekonomi Eka Prasetya berkomitmen untuk mencetak lulusan yang kompeten, berintegritas, dan siap bersaing di dunia global. Bagian Kemahasiswaan hadir untuk mendukung pengembangan potensi mahasiswa di luar akademik."}
            </p>
            <div className="flex space-x-4">
              {settings?.facebookUrl && (
                <a href={settings.facebookUrl} target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">
                  <Facebook className="h-5 w-5" />
                </a>
              )}
              {settings?.instagramUrl && (
                <a href={settings.instagramUrl} target="_blank" rel="noopener noreferrer" className="hover:text-pink-400 transition-colors">
                  <Instagram className="h-5 w-5" />
                </a>
              )}
              {settings?.youtubeUrl && (
                <a href={settings.youtubeUrl} target="_blank" rel="noopener noreferrer" className="hover:text-red-500 transition-colors">
                  <Youtube className="h-5 w-5" />
                </a>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Kontak Kami</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-blue-500 shrink-0" />
                <span>{settings?.address || "Jl. Merapi No. 8, Medan, Sumatera Utara"}</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-blue-500 shrink-0" />
                <span>{settings?.phone || "(061) 4576110"}</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-blue-500 shrink-0" />
                <span>{settings?.email || "info@ekaprasetya.ac.id"}</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Tautan Cepat</h3>
            <ul className="space-y-2 text-sm">
              {quickLinks.length > 0 ? (
                quickLinks.map((link) => (
                  <li key={link.id}>
                    <a href={link.url} className="hover:text-white transition-colors">{link.title}</a>
                  </li>
                ))
              ) : (
                <>
                  <li><a href="/" className="hover:text-white transition-colors">Beranda</a></li>
                  <li><a href="/news" className="hover:text-white transition-colors">Berita Kampus</a></li>
                  <li><a href="/gallery" className="hover:text-white transition-colors">Galeri Foto</a></li>
                  <li><a href="/downloads" className="hover:text-white transition-colors">Pusat Download</a></li>
                  <li><a href="https://ekaprasetya.ac.id" className="hover:text-white transition-colors">Website Utama</a></li>
                </>
              )}
              {user && (
                <li>
                  <button 
                    onClick={() => logout()} 
                    className="flex items-center gap-2 text-red-400 hover:text-red-300 transition-colors mt-4"
                  >
                    <LogOut className="h-4 w-4" /> Keluar
                  </button>
                </li>
              )}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-800 pt-8 text-center text-sm text-slate-500">
          <p>© {new Date().getFullYear()} STIE Eka Prasetya. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
