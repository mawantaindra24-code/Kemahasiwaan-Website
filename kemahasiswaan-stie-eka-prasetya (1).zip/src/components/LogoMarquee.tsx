import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { PartnerLogo } from '../types';
import { motion } from 'motion/react';

export default function LogoMarquee() {
  const [logos, setLogos] = useState<PartnerLogo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLogos = async () => {
      try {
        const q = query(collection(db, 'partnerLogos'), orderBy('order', 'asc'));
        const snap = await getDocs(q);
        setLogos(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as PartnerLogo)));
      } catch (error) {
        console.error('Error fetching partner logos:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchLogos();
  }, []);

  if (loading || logos.length === 0) return null;

  // Duplicate logos to create a seamless loop
  const displayLogos = [...logos, ...logos, ...logos];

  return (
    <div className="w-full bg-white py-12 border-t border-slate-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 mb-8 text-center">
        <h3 className="text-slate-400 text-sm font-bold uppercase tracking-widest">Partner & Kolaborasi</h3>
      </div>
      
      <div className="relative flex overflow-x-hidden">
        <motion.div 
          className="flex whitespace-nowrap gap-12 items-center"
          animate={{
            x: [0, -1035], // Adjust based on content width
          }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: "loop",
              duration: 20,
              ease: "linear",
            },
          }}
        >
          {displayLogos.map((logo, idx) => (
            <div 
              key={`${logo.id}-${idx}`} 
              className="flex items-center justify-center w-40 h-20 grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100"
            >
              <img 
                src={logo.imageUrl} 
                alt={logo.name} 
                className="max-w-full max-h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
