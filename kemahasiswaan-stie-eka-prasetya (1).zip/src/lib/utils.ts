import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, isValid } from "date-fns"
import { id } from "date-fns/locale"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatSafeDate(date: any, formatStr: string = 'dd MMMM yyyy') {
  if (!date) return 'Baru saja';
  
  let dateObj: Date;
  
  if (date instanceof Date) {
    dateObj = date;
  } else if (typeof date.toDate === 'function') {
    dateObj = date.toDate();
  } else if (date.seconds) { // FireStore Timestamp like object
    dateObj = new Date(date.seconds * 1000);
  } else {
    dateObj = new Date(date);
  }

  if (!isValid(dateObj)) {
    return 'Baru saja';
  }

  return format(dateObj, formatStr, { locale: id });
}
